/*
*****************************************************************************
* ParseHttpHeader.c
* Copyright (C) 2004 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/


#include "include/hspoof.h"


/*
*****************************************************************************
* ParseHttpHeader: Manipulates the received HTTP header with spoofed referer
*                  and user-agent.
*****************************************************************************
*/

int ParseHttpHeader(char *recvBuf, char *hdrRef, char *sendBuf)
{
	int i;
	char *tmpReq, *tmpHost, *tmpFile;
	
	if((tmpReq = malloc(strlen(recvBuf) - 10)) == NULL)
	{
		fprintf(stdout, "error - malloc()\n");
		return -1;
	}
	memcpy(tmpReq, &recvBuf[10 + 1], strlen(recvBuf) - 10);

	for(i = 0; tmpReq[i] != 0x2f; i++);

	if((tmpHost = malloc(i)) == NULL)
	{
		fprintf(stdout, "error - malloc()\n");
		return -2;
	}
	memcpy(tmpHost, &tmpReq[0], i);
	
	the.hdrHost = tmpHost;

	for(; tmpReq[i] != 0x20; i++);
	
	if((tmpFile = malloc(i - strlen(tmpHost))) == NULL)
	{
		fprintf(stdout, "error - malloc()\n");
		return -3;
	}
	memcpy(tmpFile, &tmpReq[strlen(tmpHost) + 1], i - strlen(tmpHost));
	
	the.hdrFile = tmpFile;

	the.hdrAccept = strstr(recvBuf, "Accept:");
	
	if(strstr(hdrRef, "http://"))
		the.hdrRef = hdrRef + 7;
	else
		the.hdrRef = hdrRef;
	
	sprintf(sendBuf, 
		"GET /%sHTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\nReferer: http://%s\r\n%s\r\n\n",
		the.hdrFile, the.hdrHost, the.hdrAgent, the.hdrRef, the.hdrAccept);

	strncpy(the.hdrHost, tmpHost, sizeof(tmpHost));
	
	free(tmpFile);
	free(tmpReq);

	return 0;
}
