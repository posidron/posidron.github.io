/*
*****************************************************************************
* hspoof.h
* Copyright (C) 2004 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/


#ifndef HSPOOF_H
#define HSPOOF_H


/*
*****************************************************************************
* HEADERS
*****************************************************************************
*/

#include <stdio.h>
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>



/*
*****************************************************************************
* MACROS
*****************************************************************************
*/

#define max(a,b)        ((a) > (b) ? (a) : (b))
#define ARRAY_SIZE      100000
#define VERSION         "0.2"
#define MAXCONNECT	5
#define DEBUGLEVEL	1
#define PROXYPORT	8080
#define USERAGENT	"hspoof"


/*
*****************************************************************************
* GLOBAL VARIABLES
*****************************************************************************
*/

int children;

unsigned int cfgDebugLevel;
unsigned int cfgProxyPort;
unsigned int cfgMaxConnect;
char *cfgUserAgent;


/*
*****************************************************************************
* GLOBAL STRUCTS
*****************************************************************************
*/

struct httpHdr{
	char *hdrFile;
	char *hdrRef;
	char *hdrHost;
	char *hdrAgent;
	char *hdrAccept;
}the;



/*
*****************************************************************************
* PROTOTYPES
*****************************************************************************
*/

int SetupProxyServer(unsigned int, unsigned int);
int SetupTargetServer(char *, unsigned int);
int ParseHttpHeader(char *, char *, char *);
void ParseConfigOptions(char *);
void PrintHelpSyntax(char *);
void SignalChild(int );



#endif
