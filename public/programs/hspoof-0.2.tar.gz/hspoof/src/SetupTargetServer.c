/*
*****************************************************************************
* SetupTargetServer.c
* Copyright (C) 2004 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/


#include "include/hspoof.h"


/*
*****************************************************************************
* SetupTargetServer: Connects to the remote host and returns on success the
*                    the socket file descriptor.
*****************************************************************************
*/

int SetupTargetServer(char *server, unsigned int debugLevel)
{
	struct sockaddr_in target;
	struct hostent *host;
	int tSock;

	if((host = gethostbyname(server)) == NULL)
	{
		fprintf(stdout, "error: target - gethostbyname()\n");
		return -1;
	}

	target.sin_family = AF_INET;
	target.sin_port = htons(80);
	target.sin_addr.s_addr = inet_addr(inet_ntoa(*(struct in_addr *)host->h_addr));

	if((tSock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		fprintf(stdout, "error: target - socket()\n");
		return -2;
	}
	
	if(connect(tSock, (struct sockaddr*)&target, sizeof(target)) == -1)
	{
		fprintf(stdout, "error: target - connect()\n");
		return -3;
	}
	
	if(debugLevel == 1 || debugLevel == 2)
	{
		fprintf(stdout, "Connected to: %s:%d [successfully]\n",
			inet_ntoa(target.sin_addr.s_addr), htons(target.sin_port));
	}
	
	return tSock;
}
