/*
*****************************************************************************
* SetupProxyServer.c
* Copyright (C) 2004 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/


#include "include/hspoof.h"


/*
*****************************************************************************
* SetupProxyServer: Setup a local server on a specified port, to wait for
*                   an incomming connection.
*****************************************************************************
*/

int SetupProxyServer(unsigned int proxyPort, unsigned int debugLevel)
{
	struct sockaddr_in proxy;
	int pSock;
	int optVal = 1;

	proxy.sin_family = AF_INET;
	proxy.sin_port = htons(proxyPort);
	proxy.sin_addr.s_addr = inet_addr("127.0.0.1");
	
	if((pSock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		fprintf(stdout, "error: proxy - socket()\n");
		return -1;
	}
	
	if(setsockopt(pSock, SOL_SOCKET, SO_REUSEADDR, &optVal, sizeof(optVal)) == -1)
	{
		fprintf(stdout, "error: proxy - setsockopt()\n");
		return -2;
	}
	
	if(bind(pSock, (struct sockaddr*)&proxy, sizeof(proxy)) == -1)
	{
		fprintf(stdout, "error: proxy - bind()\n");
		return -3;
	}
	
	if(listen(pSock, 1) == -1)
	{
		fprintf(stdout, "error: proxy - listen()\n");
		return -4;
	}
	
	if(debugLevel == 1 || debugLevel == 2)
	{
		fprintf(stdout, "Server setup: %s:%d [successfully]\n", 
			inet_ntoa(proxy.sin_addr.s_addr), htons(proxy.sin_port));
	}
	
	return pSock;
}
