/*
*****************************************************************************
* ParseConfigOptions.c
* Copyright (C) 2004 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/


#include "include/hspoof.h"


/*
*****************************************************************************
* ParseConfigOptions: Read the config file and parse out the options by 
*                     special tokens.
*****************************************************************************
*/

void ParseConfigOptions(char *confPath)
{
	FILE *confFile;
	char *confLine;
	char *confOption;
	char tmpUserAgent[50];
	unsigned int confCount = 1;
	
	if((confFile = fopen(confPath, "r")) == NULL)
	{
		fprintf(stdout, "Error: ParseConfigOtions - fopen()\n");
		exit(1);
	}

	if((confLine = (char *)malloc(255 * sizeof(char))) == NULL)
	{
		fprintf(stdout, "Error: ParseConfigOPtions - malloc()\n");
		exit(2);
	}

        while((fgets(confLine, 255, confFile)) != NULL)
        {
		if(confLine[0] != '#' && confLine[0] != '\n')
		{
			if((confOption = strstr(confLine, "PROXY_PORT = ")) != NULL)
			{
				cfgProxyPort = atoi(confOption + 12);
				
				if(cfgProxyPort < 1 || cfgProxyPort > 65535)
				{
					fprintf(stdout, "Error: ParseConfigOptions - PROXY_PORT\n");
					exit(3);
				}
			}
			else if((confOption = strstr(confLine, "USER_AGENT = ")) != NULL)
			{
				cfgUserAgent = confOption + 13;
				strncpy(tmpUserAgent, cfgUserAgent, sizeof(tmpUserAgent));
				the.hdrAgent = tmpUserAgent;
			}
			else if((confOption = strstr(confLine, "MAXIMAL_CONNECTIONS = ")) != NULL)
			{
				cfgMaxConnect = atoi(confOption + 21);

				if(cfgMaxConnect < 0)
				{
					fprintf(stdout, "Error: ParseConfigOptions - MAXIMAL_CONNECTIONS\n");
					exit(5);
				}				
			}
			else if((confOption = strstr(confLine, "DEBUG_LEVEL = ")) != NULL)
			{
				cfgDebugLevel = atoi(confOption + 13);
				
				if(cfgDebugLevel < 0 || cfgDebugLevel > 2)
				{
					fprintf(stdout, "Error: ParseConfigOptions - DEBUG_LEVEL\n");
					exit(6);
				}				
			}
			else
			{
				fprintf(stdout, "Error: ParseConfigOptions - Unspecified character\n");
				exit(7);
			}
		}
		confCount++;
	}
        free(confLine);

	if(cfgDebugLevel != 0)
	{
		fprintf(stdout, "Read config file (%s): [sucessfully]\n", confPath);
	}
}
