/*
*****************************************************************************
* hspoof.c
* Copyright (C) 2004 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/


#include "include/hspoof.h"


int main(int argc, char **argv)
{
	/* socket variables */
	struct sockaddr_in client;
	socklen_t clientSize;
	int childId, value, maxfd;
	int pSock;
	int bSock;
	int tSock;
	fd_set wHandle, rHandle;
	
	/* command line variables */
	char opt;
	char *confPath;
	unsigned int confFlag = 1;
	unsigned int debugLevel = DEBUGLEVEL;
	unsigned int proxyPort = PROXYPORT;
	unsigned int maxConnect = MAXCONNECT;
	the.hdrAgent = USERAGENT;
	
	/* file transfer variables */
	int recvBytes;
	char recvBuf[ARRAY_SIZE];
	char sendBuf[ARRAY_SIZE];
	char htmlBuf[ARRAY_SIZE];
	
	/* other variables */
	unsigned int token;


	while((opt = getopt(argc, argv, "f:p:r:u:c:d:h")) != EOF)
	{
		switch(opt)
		{
			case 'f': confFlag = 0;
				  confPath = optarg;
				break;
			case 'p': proxyPort = atoi(optarg);	
				break;
			case 'r': the.hdrRef = optarg;	
				break;
			case 'u': the.hdrAgent = optarg; 
				break;
			case 'c': maxConnect = atoi(optarg);
				break;
			case 'd': debugLevel = atoi(optarg);	
				break;
			case 'h': PrintHelpSyntax(argv[0]); 
				break;
			default:  PrintHelpSyntax(argv[0]); 
		}
	}
	
	for(token = 0; token < 23; token++)
		putchar(0x2d);
	printf("< hspoof v"VERSION" >");
	for(token = 0; token < 23; token++) 
		putchar(0x2d);
	putchar(0x0a);
	
	if(confFlag == 0)
	{
		ParseConfigOptions(confPath);
		
		proxyPort = cfgProxyPort;
		maxConnect = cfgMaxConnect;
		debugLevel = cfgDebugLevel;
		
		fprintf(stdout, "- local proxy port:\t%d\n", proxyPort);
		fprintf(stdout, "- maximum connections:\t%d\n", maxConnect);
		fprintf(stdout, "- debug level:\t\t%d\n", debugLevel);
		fprintf(stdout, "- http user-agent:\t%s\n", the.hdrAgent);
	}
	
	if(argc == 1 || debugLevel > 2 || proxyPort > 65535 || maxConnect < 1)
		PrintHelpSyntax(argv[0]);
	
	if((confFlag == 1) && (debugLevel != 0))
		fprintf(stdout, "Set maximum connections: %d [successfully]\n", maxConnect);
	
	if((pSock = SetupProxyServer(proxyPort, debugLevel)) < 0)
		return -1;

	
	/*
	********************************************************
	* Thanks to PeaceTreaty, he creates the socket routines!
	********************************************************
	*/
	
	children = 0;
	
	signal(SIGCHLD, SignalChild);
	
	while(1)
	{
		if(children < maxConnect)
		{
			if((bSock = accept(pSock, (struct sockaddr*)&client, &clientSize)) == -1)
			{
				fprintf(stdout, "error: proxy - accept()\n");
				continue;
			}
		
			children++;
		
			if((childId = fork()) == 0)
			{
				close(pSock);
		
				if(debugLevel != 0)
					fprintf(stdout, "Connection from: %s:%d [successfully]\n",
						inet_ntoa(client.sin_addr.s_addr), htons(client.sin_port));
				
				memset(&recvBuf, 0x00, sizeof(recvBuf));
			
				if((recvBytes = read(bSock, recvBuf, sizeof(recvBuf))) < 0)
				{
					fprintf(stdout, "error: client - recv()\n");
					return -4;
				}
				recvBuf[recvBytes] = '\0';
		
				if(debugLevel == 2)
				{
					putchar(0x0a);
					for(token = 0; token < 18; token++) 
					putchar(0x2d);
					fprintf(stdout, "< RECEIVING HTTP HEADER >");
					for(token = 0; token < 18; token++) 
					putchar(0x2d);
					fprintf(stdout, "\n%s\n", recvBuf);
				}

				memset(&sendBuf, 0x00, sizeof(sendBuf));
			
				if(ParseHttpHeader(recvBuf, the.hdrRef, sendBuf) < 0)
					return -5;
			
				if((tSock = SetupTargetServer(the.hdrHost, debugLevel)) < 0)
					return -6;
				
				if(debugLevel == 2)
				{
					putchar(0x0a);
					for(token = 0; token < 18; token++) 
						putchar(0x2d);
					fprintf(stdout, "< SENDING HTTP HEADER >");
					for(token = 0; token < 18; token++) 
						putchar(0x2d);
					fprintf(stdout, "\n%s\n", sendBuf);
				}

				if(write(tSock, (char*)sendBuf, strlen(sendBuf)) < 0) // recvBytes
				{
					fprintf(stdout, "error: target - send()\n");
					return -7;
				}
				
				value = fcntl(tSock, F_GETFL, 0);
			        fcntl(tSock, F_SETFL, value | O_NONBLOCK);
			
				value = fcntl(bSock, F_GETFL, 0);
				fcntl(bSock, F_SETFL, value | O_NONBLOCK);
			
				maxfd = max(tSock,bSock) + 1;
			
				while(1)
				{
					FD_ZERO(&rHandle);
					FD_ZERO(&wHandle);
				
					if(htmlBuf[0] == '\0')
						FD_SET(tSock, &rHandle);
					else
						FD_SET(bSock, &wHandle);

					select(maxfd, &rHandle, &wHandle, NULL, NULL);

					if(FD_ISSET(tSock, &rHandle))
					{
						if((recvBytes = read(tSock, htmlBuf, 1)) < 0)
						{
							fprintf(stdout, "error: target - recv()\n");
							return -8;
						}
						
						if(recvBytes == 0)
							return -9;
						else
							FD_SET(bSock, &wHandle);
					}

					if(FD_ISSET(bSock, &wHandle))
					{
						if(write(bSock, (char*)htmlBuf, 1) < 0)
						{
							if(errno != EWOULDBLOCK)
							{
								fprintf(stdout, "error: client - send()\n");
								return -10;
					        	}
						}
						memset(&htmlBuf, 0x00, sizeof(htmlBuf));
					}
				}
				close(tSock);
				close(bSock);
				exit(0);
			}
			else
				if(childId < 0)
				{
					fprintf(stdout, "error: fork()\n");
					exit(1);
				}
				close(bSock);
		}
	}

	return 0;
}



/*
*****************************************************************************
* SignalChild: Wait until the child process closed, than decrement the count
*              variable analog for one process.
*****************************************************************************
*/

void SignalChild(int signal)
{
	pid_t pid;
	int stat;
	
	while((pid = waitpid(-1, &stat, WNOHANG)) > 0)
	{
		if(WIFEXITED(stat) != 0)
			children--;
	}
	
	return;
}



/*
*****************************************************************************
* PrintHelpSyntax: Print the usage flags to stdout. For more info view the
*                  the man page.
*****************************************************************************
*/

void PrintHelpSyntax(char *progName)
{
	fprintf(stdout, "Usage: %s [-f config-file] [-p port] [-r referer] [-u user-agent] "
			"[-c connections] [-d debug-level] [-h]\n", progName);
	exit(0);
}
