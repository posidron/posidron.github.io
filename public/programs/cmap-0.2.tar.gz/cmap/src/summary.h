/*
*****************************************************************************
* cmap - summary.c
* Copyright (C) 2005 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/

#ifndef _SUMMARY_H
#define _SUMMARY_H

#include "cmap.h"

char *syntax_color_c(const char *);
int  do_log(CMAP *);
void stdout_body(CMAP *);
void stdout_stat(CMAP *);
void text_head(CMAP *);
void text_body(CMAP *);
void text_stat(CMAP *);
void html_head(CMAP *);
void html_body(CMAP *);
void html_body_hr(CMAP *);
void html_body_stat(CMAP *);
void html_footnote(CMAP *);
void html_quit(CMAP *);

#define LOG_STDOUT  0
#define LOG_TEXT    1
#define LOG_HTML    2

#define VLINK_COLOR "#000000"
#define ALINK_COLOR "#000000"
#define  LINK_COLOR "#000000"

#define T_RSLT_BODY_C "#CEE9BA"
#define T_STAT_HEAD_C "#99CC66"
#define T_STAT_BODY_C "#FFCC33"
#define TABLE_WIDTH  "500"

/* Syntax Highlighting */
#define HTML_FONT_TAG "<font color=\"#597939\">"
#define HTML_FONT_END "</font>"

#endif
