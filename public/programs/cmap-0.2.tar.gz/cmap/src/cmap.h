/*
*****************************************************************************
* cmap - cmap.h
* Copyright (C) 2005 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/


#ifndef _CMAP_H
#define _CMAP_H

#include <time.h>

struct summary {
  char *name;
  uint type;
  FILE *fh;
  char *time;
  char *date;
  clock_t tbeg;
  clock_t tend;
  char *line;
  char *comment;
  char *syntax;
  off_t fsize;
  uint bugs;
  uint lnsc;
  uint xpos;
  uint ypos;
};

typedef struct summary LOG;

struct cmap {
   char *src;
   FILE *fh;
   LOG *log;
};

typedef struct cmap CMAP;

void  do_quit(char *, ...);
void  print_version(void);
void  print_help(void);
off_t get_fsize(char *);
char  *get_date(void);
char  *get_time(void);
char  *get_filename(int);
char  *b_str(const char *, size_t);
int   iskeyword(const char *, size_t);

#define VERSION    "v0.2a"

#endif /* _CMAP_H */
