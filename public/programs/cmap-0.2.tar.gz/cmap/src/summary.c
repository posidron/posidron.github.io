/*
*****************************************************************************
* cmap - summary.c
* Copyright (C) 2005 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include "summary.h"

char *syntax_color_c(const char *buf) {
  char *tmp = NULL, *pbuf = NULL;
  uint i = 0, j = 0;
  size_t used = 0, len = 0;
  
  tmp = malloc(strlen(buf) + 1);

  if (tmp == NULL) {
    return NULL;
  }

  pbuf = malloc(sizeof (char));

  while (buf[i] != '\0') {
    if (!isalpha(buf[i])) {
      tmp[j] = '\0';

      if (buf[i] == '"') {
        len = strlen(tmp);
        pbuf = realloc(pbuf, used+len);
        memcpy(pbuf+used, tmp, len);
        used+=len;

        pbuf = realloc(pbuf, used+1);
        memcpy(pbuf+used, &buf[i], 1);
        used+=1;

        ++i;
        while (buf[i] != '"') {
          pbuf = realloc(pbuf, used+1);
          memcpy(pbuf+used, &buf[i], 1);
          used+=1;
          ++i;
        }
        tmp[0] = '\0';
      }
 
      if (tmp[0] == '\0') {
        pbuf = realloc(pbuf, used+1);
        memcpy(pbuf+used, &buf[i], 1);
        used+=1;
        ++i;
        continue;
      }

      if(iskeyword(tmp, strlen(tmp)) == 0) {
        len = strlen(HTML_FONT_TAG);
        pbuf = realloc(pbuf, used+len);
        memcpy(pbuf+used, HTML_FONT_TAG, len);
        used+=len;

        len = strlen(tmp);
        pbuf = realloc(pbuf, used+len);
        memcpy(pbuf+used, tmp, len);
        used+=len;

        len = strlen(HTML_FONT_END);
        pbuf = realloc(pbuf, used+len);
        memcpy(pbuf+used, HTML_FONT_END, len);
        used+=len;

        tmp[0] = '\0';
      }
      else {
        len = strlen(tmp);
        pbuf = realloc(pbuf, used+len);
        memcpy(pbuf+used, tmp, len);
        used+=len;

        tmp[0] = '\0';
      }
      pbuf = realloc(pbuf, used+1);
      memcpy(pbuf+used, &buf[i], 1);
      used+=1;
      j = 0;
    }
    else {
      tmp[j++] = buf[i];
    }
    ++i;
  }

  memset(pbuf+used, '\0', 1);

  free(tmp);
  
  return pbuf;
}


int do_log(CMAP *c) {  
  if (c->log->type == LOG_STDOUT) {
    stdout_body(c);
    return 0;
  }

  c->log->fh = fopen(c->log->name, "a");

  if (c->log->fh == NULL) {
    do_quit("can't write to logfile.");
  }
  
  if (c->log->type == LOG_HTML) {
    html_body(c);
  }

  if (c->log->type == LOG_TEXT) {
    text_body(c);
  }

  fclose(c->log->fh);

  return 0;
}


void stdout_body(CMAP *c) {
  fprintf(stdout, "File   : %s\n"
                  "Comment: %s\n"
                  "Details: {%d;%d} %s\n"
                  "Syntax : %s\n\n", c->src, c->log->comment, 
                  c->log->ypos, c->log->xpos, c->log->line, 
                  c->log->syntax);
}


void stdout_stat(CMAP *c) {
  fprintf(stdout, "\nStatistic\n"
                  "-------------------------------"
		  "--------------------------\n"
                  "Scan duration : %ld second(s)\n"
                  "Loaded file(s): %s\n"
                  "Total lines   : %d\n"
                  "Total size    : %ld byte(s)\n"
		  "Total bugs    : %d\n\n",
                  ((c->log->tend-c->log->tbeg) / CLOCKS_PER_SEC), 
                  c->src, c->log->lnsc, c->log->fsize, c->log->bugs);
}


void text_head(CMAP *c) {
   c->log->date = get_date();
   c->log->time = get_time();
 
   fprintf(c->log->fh, "Cmap - Summary\t\t\t"
                       "%s - %s\n"
                       "-----------------------------------------"
                       "----------------\n\n"
                       "(o) Susbect Function(s)\n"
                       "-----------------------------------------"
		       "----------------\n", 
                       c->log->date, c->log->time);
}


void text_body(CMAP *c) {
  fprintf(c->log->fh, "File   : %s\n"
                      "Comment: %s\n"
                      "Details: {%d;%d} %s\n"
                      "Syntax : %s\n\n", c->src, c->log->comment,
                      c->log->ypos, c->log->xpos, c->log->line,
                      c->log->syntax);
}


void text_stat(CMAP *c) {
  fprintf(c->log->fh, "\nStatistic\n"
                      "-------------------------------"
                      "--------------------------\n"
                      "Scan duration : %ld second(s)\n"
                      "Loaded file(s): %s\n"
                      "Total line    : %d\n"
                      "Total size    : %ld byte(s)\n"
		      "Total bugs    : %d\n\n",
                      ((c->log->tend-c->log->tbeg) / CLOCKS_PER_SEC), 
                      c->src, c->log->lnsc, c->log->fsize, c->log->bugs);
}


void html_head(CMAP *c) {
  c->log->date = get_date();
  c->log->time = get_time();

  fprintf(c->log->fh, "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD" 
    "HTML 4.0 Transitional//EN\">"
    "<html><head><title>Cmap "VERSION" - Summary</title></head>"
    "<body vlink="VLINK_COLOR" alink="ALINK_COLOR" link="LINK_COLOR">"
    "<table width="TABLE_WIDTH"><tr bgcolor=#B7C9A6><td><b>"
    "<font size=2 face=Arial color=#181D18><b>�Cmap - Summary</b>"
    "</font></td><td width=170 align=right><b>"
    "<font size=2 face=Arial color=#181D18>%s - %s��</font></b>"
    "</td></tr></table>"
    "<br><table width="TABLE_WIDTH"><tr bgcolor=#DDEACF><td>"
    "<font size=2 face=Arial color=#181D18><b>�� Susbect Function(s)"
    "</b></font></td></tr></table>", c->log->date, c->log->time);
}


void html_body(CMAP *c) {
  fprintf(c->log->fh, "<table width="TABLE_WIDTH"><tr bgcolor=#ECF9D4><td bgcolor=#D0DFC0 valign=top>"
    "<font size=2 face=Arial color=#414140><b>�Researched file</b><br>" 
    "<b>�Comment</b><br>"
    "<b>�Correct syntax</b> <br><b>�Details </b><br></font></td>"
    "<td width=380 valign=top><font size=2 face=Arial>"
    "<a href=\"%s\">%s</a><br>"
    "%s<br>"
    "%s<br>"
    "{%d;%d} %s <br>    </font></td>"
    "</tr><table>", 
      c->src, c->src, c->log->comment ,c->log->syntax,  c->log->ypos, 
     c->log->xpos, c->log->line );
}


void html_body_stat(CMAP *c) {
  fprintf(c->log->fh, "<br>"
    "<table width="TABLE_WIDTH"><tr bgcolor=#DDEACF><td>"
    "<font size=2 face=Arial color=#181D18><b>�Statistic</b></face>"
    "</td></tr></table>"
    "<table width="TABLE_WIDTH"><tr bgcolor=#ECF9D4>"
    "<td bgcolor=#D0DFC0 valign=top>"
    "<font size=2 face=Arial color=#414140>"
    "<b>�Scan duration</b><br> "
    "<b>�Loaded file(s) </b><br>"
    "<b>�Total lines</b><br> "
    "<b>�Total size </b><br>  "
    "<b>�Total bugs</b><br></font></td>"
    "<td width=380 valign=top>"
    "<font size=2 face=Arial>"
    "%ld second(s)<br><a href=\"%s\">%s</a><br>%d<br>%ld bytes<br>%d</font></td>"
    "</tr></table><table width="TABLE_WIDTH"><tr bgcolor=#BFD2AC>"
    "<td><font color=#BFD2AC>.</font></td></tr></table>", 
    ((c->log->tend-c->log->tbeg) / CLOCKS_PER_SEC),
    c->src, c->src, c->log->lnsc, c->log->fsize, c->log->bugs);
}


void html_body_hr(CMAP *c) {
  fprintf(c->log->fh, "<table width="TABLE_WIDTH"><tr bgcolor=#BFD2AC><td>"
    "<font color=#BFD2AC>.</font></td></tr></table>");
}


void html_footnote(CMAP *c) {
  fprintf(c->log->fh, "<br>"
    "<table width="TABLE_WIDTH"><tr><td><center>"
    "<font size=2 face=Arial>(C) 2002 - 2005 Tripbit, www.tripbit.org\n</font>"
    "</center></td></tr></table>");
}


void html_quit(CMAP *c) {
  fprintf(c->log->fh, "</body><html>");
}
