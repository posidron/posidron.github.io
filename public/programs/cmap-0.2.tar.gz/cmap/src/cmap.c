/*
*****************************************************************************
* cmap - cmap.c
* Copyright (C) 2005 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "cmap.h"
#include "engine.h"
#include "summary.h"

int main(int argc, char **argv) {
  CMAP *c = NULL;
  short int set_ansi = 0;
  short int set_frmt = 0;
  short int set_buff = 0;
  int opt;
  char *optstr = "c:o:afbhv";


  c = malloc(sizeof (CMAP));
  c->log = malloc(sizeof (LOG));

  c->src       = NULL;
  c->log->name = NULL;
 
  while ((opt = getopt(argc, argv, optstr)) != -1) {
    switch (opt) {
      case 'c':
        c->src = optarg;
        /*
        for (; optind < argc; ++optind, i++) {
          if (strncmp(argv[optind], "-", 1) == 0)
            break;
          len = strlen(argv[optind]) + 1;
          strncpy(c->src[i], argv[optind], len);
        }
	*/
        break;
      case 'o':
        if (strncmp(optarg, "t", 1) == 0) {
          c->log->type = LOG_TEXT;
          c->log->name = argv[optind];
        }
        else if (strncmp(optarg, "h", 1) == 0) {
          c->log->type = LOG_HTML;
          c->log->name = argv[optind];
        }
        else if (strncmp(optarg, "s", 1) == 0) {
          c->log->type = LOG_STDOUT;
        }
        break;
      case 'a':
        ++set_ansi;
        break;
      case 'f':
        ++set_frmt;
        break;
      case 'b':
        ++set_buff;
        break;
      case 'h':
        print_help();
        break;
      case 'v':
        print_version();
        break;
      default:
        print_help();
        do_quit("this argument is not available.");
    }
  }

 /* dude, my brain is not a meta parser, for
  * all the dump combinations you typing in.
  * but let us check some things for people,
  * who are to stupid to read the help.
  */

  if ((set_ansi == 0) && (set_frmt == 0) && (set_buff == 0)) {
    do_quit("no method was specified.");
  }
  
  if (c->src == NULL) {
    do_quit("source file is missing.");
  }

  c->fh = fopen(c->src, "r");

  if (c->fh == NULL) {
    do_quit("can't read the source file.");
  }

  if (c->log->name == NULL) {
    c->log->type = LOG_STDOUT;
  }
  else {
    c->log->fh = fopen(c->log->name, "w");

    if (c->log->fh == NULL) {
      do_quit("unable to set given file as logfile.");
    }
  }

  c->log->fsize = get_fsize(c->src);

  printf("\nStarting Cmap "VERSION" (releases.tripbit.org) at ");
  c->log->time = get_time();
  printf("%s\n\n", c->log->time);

  c->log->tbeg = clock();

  printf ("Results Summary\n"
          "------------------------------"
	  "---------------------------\n"); 
  
  if (c->log->type == LOG_HTML) {
    html_head(c);
    fclose(c->log->fh);
  }
  
  if (c->log->type == LOG_TEXT) {
    text_head(c);
    fclose(c->log->fh);
  }

  c->log->fh = fopen(c->log->name, "a");

  if (set_ansi == 1) {
    grep(c, GREP_ANSI);
  }

  if (set_frmt == 1) {
    grep(c, GREP_FORMAT);    
  }

  if (set_buff == 1) {
    grep(c, GREP_STRING); 
  }

  c->log->tend = clock();

  if (c->log->bugs == 0) {
    printf ("Nothing was found.\n\n");
    stdout_stat(c);
    return -1;
  }

  if ((c->log->fh != NULL) && (c->log->type != LOG_STDOUT)) {
    printf("View %s\n\n", c->log->name);
  }

  /* html log close */
  if (c->log->type == LOG_HTML) {
    c->log->fh = fopen(c->log->name, "a");

    html_body_hr(c);
    html_body_stat(c);
    html_footnote(c);
    html_quit(c);
    stdout_stat(c);
    fclose(c->log->fh);
  }

  /* stdout log close */
  if (c->log->type == LOG_STDOUT) {
    stdout_stat(c);
  }

  /* text log close */
  if (c->log->type == LOG_TEXT) {
    c->log->fh = fopen(c->log->name, "a");
    text_stat(c);
    stdout_stat(c);
    fclose(c->log->fh);
  }

  free(c);
  
  return 0;
}


void do_quit(char *fmt, ...) {  
  va_list args;

  va_start(args, fmt);
  fprintf(stderr, "cmap: ");
  vfprintf(stderr, fmt, args);
  fprintf(stderr, "\n");
  va_end(args);
  exit(1);
}


off_t get_fsize(char *fp) {
  off_t fsize;
  struct stat stbuf;

  if (stat(fp, &stbuf) != -1) { 
    fsize = stbuf.st_size;
    return fsize;
  }
  
  return 0;
}


char *get_date(void) {
  char *date;
  struct tm *stime;
  time_t sec;

  time(&sec);
  stime = localtime(&sec);

  date = malloc(80);

  if (date == NULL) {
    do_quit("not enough memory.");
  }

  strftime(date, 80, "%d/%m/%Y", stime);
  
  return date;
}


char *get_time(void) {
  char *ptime;
  struct tm *stime;
  time_t sec;

  time(&sec);
  stime = localtime(&sec);

  ptime = malloc(80);

  if (ptime == NULL) {
    do_quit("not enough memory.");
  }

  strftime(ptime, 80, "%I:%M:%S %p", stime);

  return ptime;
}


int iskeyword(const char *p, size_t len) {
  uint i = 0;
  char *kw[29] = {
    "int" ,"char"  ,"float","const" ,"continue",
    "auto","break" ,"case" ,"double","unsigned", 
    "enum","long"  ,"void" ,"short" ,"default" ,
    "if"  ,"sizeof","while","return","typedef" , 
    "for" ,"struct","main" ,"union" ,"register",
    "do"  ,"signed","else" ,"volatile"
  };

  if (p != NULL) {
    for (i = 0; i <= 28; i++) {
       if (strncmp(kw[i], p, len) == 0)
         return 0;
    }
  }

  return -1;
}


void print_version(void) {
  printf("cmap "VERSION", written by posidron <posidron@tripbit.org>\n"
         "   (C) 2002 - 2005 Tripbit, http://www.tripbit.org\n");
  exit(0);
}


void print_help(void) {
  printf("\nCmap "VERSION" Usage: cmap [Scan Type(s)] [File(s)] [Summary Type(s)]\n\n");
  printf(" -a                 Greps out vulnerable ANSI C functions.\n");
  printf(" -b                 Greps out functions, which are vulnerable\n"
         "                    to buffer overflow attacks.\n");
  printf(" -f                 Greps out functions, which are vulnerable\n"
         "                    to format string attacks.\n\n");
  printf(" -c                 Specifies the source, which you will audit.\n\n");
  printf(" -o <type> <file>   Specifies the summary output file:\n");
  printf("                    -oh <file>.html ( html )\n");
  printf("                    -ot <file>.txt  ( text )\n");
  printf("                    -os             (stdout)\n\n");
  printf(" -h                 Prints this help message.\n");
  printf(" -v                 Prints the current version.\n\n");
  printf("Example: ./cmap -f -c samples/sample.c -oh log.html\n\n");
  exit(0);
}
