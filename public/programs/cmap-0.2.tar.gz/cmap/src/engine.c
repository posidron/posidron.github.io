/*
*****************************************************************************
* cmap - engine.c
* Copyright (C) 2005 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/types.h>
#include "summary.h"
#include "engine.h"

struct ansi_lib {
  char *fstr;
  int param;
  }probe[] = {
    {"strcpy",   2},
    {"gets",     1},
    {"setenv",   3},
    {"getenv",   1},
    {"strcat",   2},
    {"sprintf",  2},
    /**************/
    {"syslog",   2},
    {"printf",   1},
    {"scanf",    1},
    {"fscanf",   2},
    {"sscanf",   2},
    {"fprintf",  2},
    {"sprintf",  2},
    {"snprintf", 3},
    {"system",   1}
};

struct syntax {
  char *fsyn;
  }syntax[] = {
    {"char *strcpy(char *dest, const char *src);"                         },
    {"char *gets(char *str);"                                             },
    {"int setenv (const char *name, const char *value, int overwrite);"   },
    {"char *getenv(const char *name);"                                    },
    {"char *strcat(char *dest, const char *src);"                         },
    {"int sprintf(char *str, const char *format, ...);"                   },
    /**********************************************************************/
    {"void syslog(int priority, const char *message, ...);"               },
    {"int printf(const char *format, ...);"                               },
    {"int scanf(const char *format, ...);"                                },
    {"int fscanf(FILE *stream, const char *format, ...);"                 },
    {"int sscanf(const char *str, const char *format, ...);"              },
    {"int fprintf(FILE *stream, const char *format, ...);"                },
    {"int sprintf(char *str, const char *format, ...);"                   },
    {"int snprintf(char *str, size_t n, const char *format, ...);"        },
    {"int system(const char *string);"                                    }
};

struct category {
  char *fcat;
  }category[] = {
    {"This function is potential vulnerable to a buffer overflow attack."},
    /*****************************************************************/
    {"This function is potential vulnerable to a format string attack."  }
};


int grep(CMAP *c, int type) {
  char buf[MAX_LINE_SIZE];
  int  r, i = 0, ln = 0;
  static uint b = 0;

  
  c->log->bugs = b;

  if (type == GREP_FORMAT) {
    i = 6;
  }

  while (probe[i].fstr) {
    rewind(c->fh);
    while (fgets(buf, sizeof (buf), c->fh) != NULL) {
      ln++;
      
      switch (type) {
        case GREP_ANSI:
          r = check_ansi(buf, probe[i].fstr);
        break;
        case GREP_FORMAT:
          r = check_frmt(buf, probe[i].fstr, probe[i].param);
        break;
        case GREP_STRING:
          r = check_buff(buf, probe[i].fstr, probe[i].param);
        break;
      }

      if (r > 0) {
        buf[strlen(buf) - 1] = '\0';

        if (c->log->type == LOG_HTML) {
          c->log->syntax = syntax_color_c(syntax[i].fsyn);
          c->log->line   = syntax_color_c(buf);
        }
        else {
          c->log->syntax = syntax[i].fsyn;
          c->log->line   = buf;
        }

        c->log->xpos   = r;
        c->log->ypos   = ln;

       if (i >= 6)
          c->log->comment = category[1].fcat;
        else
          c->log->comment = category[0].fcat;

        do_log(c);

        c->log->bugs++;
      }
    }
    i++;
    c->log->lnsc = ln;
    ln = 0;
  }

  fclose(c->fh);

  return 0;
}


int check_frmt(const char *buf, const char *str, int para) {
  char   *r;
  int    args = 0;
  int    hops = 0;
  int    fend = 0;
  size_t spos, epos;

  r = strstr(buf, str);

  if (r == NULL) {
    return -1;
  }

  spos = strlen(buf) - strlen(r) - 1;
  epos = strlen(str);

  if ((*(r+epos) == 0x20) || (*(r+epos) == 0x28)) {
    if ((*(buf+(spos)) == 0x20) 
     || (*(buf+(spos)) == 0x3D)
     || (*(buf+(spos)) == 0x2A)
     || (*(buf+(spos)) == 0x3B)
     || (*(buf+(spos)) == 0x29)
     || (*(buf+(spos)) == 0x2C)) {
      while (fend == 0) {
        ++epos;
        switch (*(r+epos)) {
          case ',':
           ++args;
          break;
          case '"':
           ++hops;
          break;
          case ')':
            fend = 1;
          break;
        }
      }

      if (para == (args+1) && hops == 0) { 
        return spos+1;
      }
    }
  }

  return -2;
}


int check_ansi(const char *buf, const char *str) {
  char   *r;
  size_t spos, epos;

  r = strstr(buf, str);

  if (r == NULL) {
    return -1;
  }
  
  spos = strlen(buf) - strlen(r) - 1;
  epos = strlen(str);

  if ((*(r+epos) == 0x20) || (*(r+epos) == 0x28)) {
    if ((*(buf+(spos)) == 0x20) 
     || (*(buf+(spos)) == 0x3D)
     || (*(buf+(spos)) == 0x2A)
     || (*(buf+(spos)) == 0x3B)
     || (*(buf+(spos)) == 0x29)
     || (*(buf+(spos)) == 0x2C)) {
      return spos+1;
    }
  }

  return -2;
}


int check_buff(const char *buf, const char *str, int para) {
  char   *r;
  size_t spos, epos;

  r = strstr(buf, str);

  if (r == NULL) {
    return -1;
  }

  spos = strlen(buf) - strlen(r) - 1;
  epos = strlen(str);

  if ((*(r+epos) == 0x20) || (*(r+epos) == 0x28)) {
    if ((*(buf+(spos)) == 0x20)    // space
     || (*(buf+(spos)) == 0x3D)    // =
     || (*(buf+(spos)) == 0x2A)    // *
     || (*(buf+(spos)) == 0x3B)    // ;
     || (*(buf+(spos)) == 0x29)    // )
     || (*(buf+(spos)) == 0x2C)) { // ,
      return spos+1;
    }
  }

  return -2;
}
