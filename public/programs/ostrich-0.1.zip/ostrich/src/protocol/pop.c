#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "../include/protocol.h"

char *pop_cmd[] =
{
  "LIST", "RETR", "DELE", "TOP", "UIDL", "USER", "PASS", "APOP", NULL
};

int pop_setup(void)
{
  char host[256];
  char user[256];
  char pass[256];
  unsigned int port;

  port = DEFAULT_POP_PORT;
  memset(host, '\0', sizeof (host));
  memcpy(host, DEFAULT_HOST, strlen(DEFAULT_HOST));
  memset(user, '\0', sizeof (user));
  memset(pass, '\0', sizeof (pass));

  while (1)
  {
    _clean();
    _header("POP Configuration");
    if(strlen(host) != 0)
      printf("<1> Hostname: %s\n", host);
    else
      printf("<1> Hostname:\n");
    if(port > 0)
      printf("<2> Port....: %d\n", port);
    else
      printf("<2> Port....:\n");
    if(strlen(user) != 0)
      printf("<3> Username: %s\n", user);
    else
      printf("<3> Username:\n");
    if(strlen(pass) != 0)
      printf("<4> Password: %s\n", pass);
    else
      printf("<4> Password:\n");
    _footer();
    printf("[E] Execute\n");
    printf("[M] Back [Main Menu]\n");
    printf("[B] Back [Protocol Selection]\n");
    printf("[Q] Quit\n");
    printf("\nSelect> ");

    switch (_input())
    {
      case '1': printf("Hostname: ");
                scanf("%255s", host);
                break;
      case '2': printf("Port    : ");
                scanf("%u", &port);
                break;
      case '3': printf("Username: ");
                scanf("%255s", user);
                break;
      case '4': printf("Password: ");
                scanf("%255s", pass);
                break;
      case 'E':
      case 'e': pop_start(host, port, user, pass);
                break;
      case 'M':
      case 'm': main_menu();
      case 'B':
      case 'b': return 0;
      case 'Q':
      case 'q': _leave();
      default : break;
    }
  }
  return -1;
}

int pop_start(char *host, unsigned short port, char *user, char *pass)
{
  int sock, rbytes, sbytes;
  char *cmd, *str;
  char buffer[DEFAULT_RESPONSE_SIZE];

  _clean();

  while (1)
  {
    if ((sock = handle_connect(host, port)) < 0)
      return -1;

    if (pop_plain_auth(sock, user, pass) < 0)
      return -2;

    cmd = pop_cmd[rand_int(0, MAX_INDEX(pop_cmd))];
    str = rand_string();

    sbytes = ostrich_send(sock, "%s %s\r\n", cmd, str);
    if (sbytes == -1)
    {
      close(sock);
      _error("cant send to host!\n");
      return -3;
    }
    printf("%s|send:%6u|%s %s %.60s\n", COLOR_SEND, sbytes, NORMAL, cmd, str);

    rbytes = ostrich_recv(sock, buffer, sizeof (buffer) - 1);
    if (rbytes == -1)
    {
      close(sock);
      _error("can't recv from host!\n");
      return -4;
    }
    printf("%s|recv:%6u|%s %.60s\n", COLOR_RECV, rbytes, NORMAL, buffer);

    close(sock);
  }

  return -5;
}

int pop_plain_auth(int sock, char *user, char *pass)
{
  int nbytes;
  char temp[256];

  /* recv banner */
  if ((recv(sock, temp, sizeof (temp) - 1, 0)) == -1)
  {
    close(sock);
    _error("error: recv()\n");
    return -1;
  }
  temp[0] = '\0';

  /* send username */
  snprintf(temp, sizeof (temp), "USER %s\r\n", user);
  if (send(sock, temp, strlen(temp), 0) == -1)
  {
    close(sock);
    _error("error: send()\n");
    return -2;
  }

  /* recv return code */
  if ((recv(sock, temp, sizeof (temp) - 1, 0)) == -1)
  {
    close(sock);
    _error("error: recv()\n");
    return -3;
  }
  temp[0] = '\0';

  /* send password */
  snprintf(temp, sizeof (temp), "PASS %s\r\n", pass);
  if (send(sock, temp, strlen(temp), 0) == -1)
  {
    close(sock);
    _error("error: send()\n");
    return -2;
  }
  temp[0] = '\0';

  /* recv return code of athentication */
  if ((nbytes = recv(sock, temp, sizeof (temp) - 1, 0)) == -1)
  {
    close(sock);
    _error("error: recv()\n");
    return -3;
  }
  temp[nbytes] = '\0';

  if (strstr(temp, "OK") == NULL)
  {
    close(sock);
    _error("error: authentication failed!\n");
    return -4;
  }

  return sock;
}