#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "../include/protocol.h"

char *ftp_cmd[] =
{
  "ACCOUNT", "CWD", "CDUP", "PORT", "MKD", "RMD", "PWD", "SITE", "ACCT",
  "SMNT", "TYPE", "STRU", "MODE", "RETR", "STOR", "APPE", "ALLO", "REST",
  "RNFR", "RNTO", "DELE", "LIST", "NLIST", "STAT", "HELP", NULL
};

int ftp_setup(void)
{
  char host[256];
  char user[256];
  char pass[256];
  unsigned int port;

  port = DEFAULT_FTP_PORT;
  memset(host, '\0', sizeof (host));
  memset(user, '\0', sizeof (user));
  memset(pass, '\0', sizeof (pass));
  memcpy(host, DEFAULT_HOST, strlen(DEFAULT_HOST));
  memcpy(user, DEFAULT_FTP_USER, strlen(DEFAULT_FTP_USER));
  memcpy(pass, DEFAULT_FTP_PASS, strlen(DEFAULT_FTP_PASS));

  while (1)
  {
    _clean();
    _header("FTP Configuration");
    if (strlen(host) != 0)
      printf("<1> Hostname: %s\n", host);
    else
      printf("<1> Hostname:\n");
    if (port > 0)
      printf("<2> Port    : %d\n", port);
    else
      printf("<2> Port    :\n");
    if (strlen(user) != 0)
      printf("<3> Username: %s\n", user);
    else
      printf("<3> Username:\n");
    if (strlen(pass) != 0)
      printf("<4> Password: %s\n", pass);
    else
      printf("<4> Password:\n");
    _footer();
    printf("[E] Execute\n");
    printf("[M] Back [Main Menu]\n");
    printf("[B] Back [Protocol Selection]\n");
    printf("[Q] Quit\n");
    printf("\nSelect> ");

    switch (_input())
    {
      case '1': printf("Hostname: ");
                scanf("%255s", host);
                break;
      case '2': printf("Port    : ");
                scanf("%u", &port);
                break;
      case '3': printf("Username: ");
                scanf("%255s", user);
                break;
      case '4': printf("Password: ");
                scanf("%255s", pass);
                break;
      case 'E':
      case 'e': ftp_start(host, port, user, pass);
                break;
      case 'M': 
      case 'm': main_menu();
      case 'B': 
      case 'b': return 0;
      case 'Q':
      case 'q': _leave();
      default : break;
    }
  }
  return -1;
}

int ftp_start(char *host, unsigned short port, char *user, char *pass)
{
  int sock, rbytes, sbytes;
  char *cmd, *str;
  char buffer[DEFAULT_RESPONSE_SIZE];

  _clean();

  while (1)
  {
    if ((sock = handle_connect(host, port)) < 0)
      return -1;

    if (ftp_plain_auth(sock, user, pass) < 0)
      return -2;

    cmd = ftp_cmd[rand_int(0, MAX_INDEX(ftp_cmd))];
    str = rand_string();

    sbytes = ostrich_send(sock, "%s %s\r\n", cmd, str);
    if (sbytes == -1)
    {
      close(sock);
      _error("cant send to host!\n");
      return -3;
    }
    printf("%s|send:%6u|%s %s %.60s\n", COLOR_SEND, sbytes, NORMAL, cmd, str);

    rbytes = ostrich_recv(sock, buffer, sizeof (buffer) - 1);
    if (rbytes == -1)
    {
      close(sock);
      _error("can't recv from host!\n");
      return -4;
    }
    printf("%s|recv:%6u|%s %.60s\n", COLOR_RECV, rbytes, NORMAL, buffer);

    close(sock);
  }

  return -3;
}

int ftp_plain_auth(int sock, char *user, char *pass)
{
  int nbytes;
  char temp[256];

  /* recv banner */
  if ((recv(sock, temp, sizeof (temp) - 1, 0)) == -1)
  {
    close(sock);
    _error("error: recv()\n");
    return -1;
  }
  temp[0] = '\0';

  /* send username */
  snprintf(temp, sizeof (temp), "USER %s\r\n", user);
  if (send(sock, temp, strlen(temp), 0) == -1)
  {
    close(sock);
    _error("error: send()\n");
    return -2;
  }
  temp[0] = '\0';

  /* recv return code of username */
  if ((recv(sock, temp, sizeof (temp) - 1, 0)) == -1)
  {
    close(sock);
    _error("error: recv()\n");
    return -3;
  }
  temp[0] = '\0';

  /* send password */
  snprintf(temp, sizeof (temp), "PASS %s\r\n", pass);
  if (send(sock, temp, strlen(temp), 0) == -1)
  {
    close(sock);
    _error("error: send()\n");
    return -4;
  }

  /* recv return code of authentication */
  if ((nbytes = recv(sock, temp, sizeof (temp) - 1, 0)) == -1)
  {
    close(sock);
    _error("error: recv()\n");
    return -5;
  }
  temp[nbytes] = '\0';

  if (strstr(temp, "230") == NULL)
  {
    close(sock);
    _error("error: authentication failed!\n");
    return -6;
  }

  return sock;
}
