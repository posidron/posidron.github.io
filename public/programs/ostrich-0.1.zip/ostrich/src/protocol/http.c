#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "../include/protocol.h"

/* http 1.1 & http 1.0 */
char *http_cmd[] =
{
  "GET", "POST", "TRACE", "CONNECT", "DELETE", "HEAD", "PUT", "OPTIONS", NULL
};

char *http_sub_cmd[] =
{
  "Host", "Content-length", "User-Agent", "Accept-Charset", "Accept", 
  "Accept-Encoding", "Accept-Ranges", "Allow", "Authorization", "Cache-Control",
  "Referer", "Vary", "Via", NULL
};

/* must be audit too, in some way :/
Accept-Encoding: compress;q=0.5, gzip;q=1.0
Accept-Encoding: gzip;q=1.0, identity; q=0.5, *;q=0
*/

int http_setup(void)
{
  char host[256];
  unsigned int port;

  port = DEFAULT_HTTP_PORT;
  memset(host, '\0', sizeof (host));
  memcpy(host, DEFAULT_HOST, strlen(DEFAULT_HOST));

  while (1)
  {
    _clean();
    _header("HTTP Configuration");
    if(strlen(host) != 0)
      printf("<1> Hostname: %s\n", host);
    else
      printf("<1> Hostname:\n");
    if(port > 0)
      printf("<2> Port....: %d\n", port);
    else
      printf("<2> Port....:\n");
    _footer();
    printf("[E] Execute\n");
    printf("[M] Back [Main Menu]\n");
    printf("[B] Back [Protocol Selection]\n");
    printf("[Q] Quit\n");
    printf("\nSelect> ");

    switch (_input())
    {
      case '1': printf("Hostname: ");
                scanf("%255s", host);
                break;
      case '2': printf("Port    : ");
                scanf("%u", &port);
                break;
      case 'E':
      case 'e': http_start(host, port);
                break;
      case 'M':
      case 'm': main_menu();
      case 'B': 
      case 'b': return 0;
      case 'Q':
      case 'q': _leave();
      default : break;
    }
  }
  return -1;
}

int http_start(char *host, unsigned short port)
{
  int sock, rbytes, sbytes;
  char *cmd, *str, *sub_cmd, *sub_str, b_http[9000];
  char buffer[DEFAULT_RESPONSE_SIZE];

  _clean();

  while (1)
  {
    if ((sock = handle_connect(host, port)) < 0)
      return -1;

    /* try to generate a request */
    cmd = http_cmd[rand_int(0, MAX_INDEX(http_cmd))];
    str = rand_string();
    snprintf(b_http, sizeof (b_http), "%s %s HTTP/1.0", cmd, str);
    sbytes = ostrich_send(sock, "%s\r\n", b_http);
    if (sbytes == -1)
    {
      close(sock);
      _error("cant send to host!\n");
      return -2;
    }

    printf("%s|send:%6u|%s %s %.60s\n", COLOR_SEND, sbytes, NORMAL, cmd, str);

    /* try to generate a random header for the request */
    for (; rand_int(0, MAX_INDEX(http_sub_cmd)); )
    { 
      sub_cmd = http_sub_cmd[rand_int(0, MAX_INDEX(http_sub_cmd))];
      sub_str = rand_string();
      snprintf(b_http, sizeof (b_http), "%s: %s", cmd, str);
      ostrich_send(sock, "%s\r\n", b_http);
      printf("%s: %s\n", sub_cmd, sub_str);
    }

    sbytes = ostrich_send(sock, "\r\n");
    if (sbytes == -1)
    {
      close(sock);
      _error("cant send to host!\n");
      return -2;
    }

    rbytes = ostrich_recv(sock, buffer, sizeof (buffer) - 1);
    if (rbytes == -1)
    {
      close(sock);
      _error("can't recv from host!\n");
      return -3;
    }
    printf("%s|recv:%6u|%s %.60s\n", COLOR_RECV, rbytes, NORMAL, buffer);

    close(sock);
  }

  return -4;
}
