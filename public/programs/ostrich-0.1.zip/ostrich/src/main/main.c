/* 
**  Ostrich v0.1 2005
**  -----------�--------------------------------------------
**  History
**     FTGate 4 IMAPD Remote Buffer Overrun
**     Eudora WorldMail 3 IMAPD Remote Heap Overflow
**     VMware 5.0.0 NAT Remote Denial of Service 
**
**  --------------------------------------------------------
**  Environment
**     Linux 2.6.8-2-686, gcc 3.3.5 (Debian 1:3.3.5-13)
**     OpenBSD 3.6, 
**     Windows XP Professional, gcc 3.4.2 (mingw-special)
**
**  --------------------------------------------------------
*/

#include "../include/main.h"

int main (void)
{
  main_menu();

  return -1;
}

