#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "../include/main.h"

const char array[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
                     " 1234567890!?@#$&�%^*()_-+={}[]\\/|~<>,.:;'\"";

char *rand_string(void)
{
  int i, n;
  static char buff[DEFAULT_RANDOM_SIZE-100];

  //memset(buff, '\0', sizeof (buff));

  /* random length */
  n = rand() % sizeof (buff) - 1;

  switch (rand() % 3)
  {
    case 0: /* whitespace(s) as n argmuent */
            for (i = 0; i <= n; i++)
            {
              buff[i] = array[1];
            }
            for (; rand() % 5 ;)
            { /* set space at rand() position */
              buff[rand() % n] = array[52];
            }
            break;
    case 1: /* string with random chars */
            for (i = 0; i <= n; i++)
            {
              buff[i] = array[rand() % sizeof (array)];
            }
            break;
    case 2: /* string with single char */
            for (i = 0; i <= n; i++)
            {
              buff[i] = array[1];
            }
            break;
  }

  return buff;
}

int rand_int(int min, int max)
{
  return rand() % (max - min + 1) + min;
}