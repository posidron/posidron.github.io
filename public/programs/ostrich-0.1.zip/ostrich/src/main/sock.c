#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include "../include/main.h"

int tcp_connect(char *host, unsigned short port)
{
  int sock;
  struct hostent *h;
  struct sockaddr_in sa;
#ifdef _WIN32
  WSADATA wsa;

  if (WSAStartup(MAKEWORD(1, 1), &wsa))
  {
    printf("error: WSAStartup()\n");
    return -1;
  }
#endif

  if((h = gethostbyname(host)) == NULL)
  {
    printf("error: gethostbyname()\n");
    return -2;
  }

  if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1)
  {
    printf("error: socket()\n");
    return -3;
  }

  sa.sin_addr = *((struct in_addr*)h->h_addr);
  sa.sin_family = AF_INET;
  sa.sin_port = htons(port);

  if (connect(sock, (struct sockaddr*)&sa, sizeof (sa)) == -1)
  {
    close(sock);
    printf("error: connect()\n");
    return -4;
  }

  return sock;
}

int ostrich_send(int sock, char *fmt, ...)
{
  va_list va;
  char buff[DEFAULT_RANDOM_SIZE];
  
  va_start(va, fmt);
  vsnprintf(buff, sizeof (buff) - 1, fmt, va);
  va_end(va);

  return send(sock, buff, strlen(buff), 0);
}

int ostrich_recv(int sock, void *buff, size_t msize)
{
  msize = recv(sock, buff, msize, 0);
  memcpy(buff+msize, "\0", 1);
  return msize;
}

int handle_connect(char *host, unsigned short port)
{
  int sock, err = 0;

  do
  {
    sock = tcp_connect(host, port);
    if (sock < 0)
    {
      err += 1;
      if (err == 5)
      {
        printf("error: ostrich couldn't connect to host! (5 times)\n");
        sleep(2);
        return -2;
      }
      sleep(2);
    }
  } 
  while (sock < 0);

  return sock;
}

