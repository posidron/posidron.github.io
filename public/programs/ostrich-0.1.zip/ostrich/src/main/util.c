#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include "../include/main.h"

void _clean(void)
{
#ifdef _WIN32
  system("cls");
#else
  system("clear");
#endif
}

void _leave(void)
{
  printf("\nSayonara!\n\n");
  exit(0);
}

int _input(void)
{
  int c;

  c = getchar();
  fflush(stdout);
  fflush(stdin);
  
  return c;
}

int _error(char *fmt, ...)
{
  va_list args;
  
  va_start(args, fmt);
  fprintf(stderr, "error: ");
  vfprintf(stderr, fmt, args);
  fprintf(stderr, "\n");
  va_end(args);

  sleep(2);

  return -1;
}
