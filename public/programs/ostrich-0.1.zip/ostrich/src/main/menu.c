#include <stdio.h>
#include <string.h>
#include "../include/main.h"

void _header(char *title)
{
  unsigned char i;

  printf("%s - %s\n", VERSION, title);
  x = 3 + strlen(VERSION) + strlen(title);

  for (i = 0; i < x; i++)
    printf("-");
  printf("\n\n");
}

void _footer(void)
{
  unsigned char i;

  printf("\n");
  for (i = 0; i < x; i++)
    printf("-");
  printf("\n");
}

int main_menu(void)
{
  while (1)
  {
    _clean();
    _header("Main Menu");
    printf("<1> Protocols\n");
    printf("<2> Files\n");
    printf("<3> Kernel\n");
    _footer();
    printf("[Q] Quit\n");
    printf("\nSelect> ");

    switch (_input())
    {
      case '1': protocol_menu();
                break;
      case '2': file_menu();
                break;
      case '3': kernel_menu();
                break;
      case 'Q':
      case 'q': _leave();
      default : break;
    }
  }
  return -1;
}

int protocol_menu(void)
{
  while (1)
  {
    _clean();
    _header("Protocol Penetration");
    printf("<1> Internet Message Access Protocol\n");
    printf("<2> Simple Mail Transfer Protocol\n");
    printf("<3> Post Office Protocol\n");
    printf("<4> File Transfer Protocol\n");
    printf("<5> Hyper Text Transfer Protocol\n");
    /* add new items here */
    _footer();
    printf("[B] Back [Main Menu]\n");
    printf("[Q] Quit\n");
    printf("\nSelect> ");

    switch (_input())
    {
      case '1': imap_setup();
                break;
      case '2': smtp_setup();
                break;
      case '3': pop_setup();
                break;
      case '4': ftp_setup();
                break;
      case '5': http_setup();
      case 'B':
      case 'b': return 0;
      case 'Q':
      case 'q': _leave();
      default : break;
    }
  }
  return -1;
}

int file_menu(void)
{
  while (1)
  {
    _clean();
    _header("File Penetration");
    printf("<1> Virtual Card File\n");
    printf("<2> Hyper Text Markup Language\n");
    _footer();
    printf("[B] Back [Main Menu]\n");
    printf("[Q] Quit\n");
    printf("\nSelect> ");

    switch (_input())
    {
      case '1': //imap_setup();
                break;
      case '2': //html_setup();
                break;
      case 'B':
      case 'b': return 0;
      case 'Q':
      case 'q': _leave();
      default : break;
    }
  }
  return -1;
}

int kernel_menu(void)
{
  while (1)
  {
    _clean();
    _header("Kernel Penetration");
    printf("<1> Linux System Calls\n");
    _footer();
    printf("[B] Back [Main Menu]\n");
    printf("[Q] Quit\n");
    printf("\nSelect> ");

    switch (_input())
    {
#ifndef _WIN32
      case '1': linux_syscall_setup();
                break;
#else
      case '1': printf("Option is deactivated to this system!\n");
                sleep(2);
                break;
#endif       
      case '2': //html_setup();
                break;
      case 'B':
      case 'b': return 0;
      case 'Q':
      case 'q': _leave();
      default : break;
    }
  }
  return -1;
}

/* add new main categories here */
