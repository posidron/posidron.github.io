
#ifndef _PROTOCOL_H
#define _PROTOCOL_H

#ifdef _WIN32
  #include <winsock2.h>
  #pragma comment(lib, "ws2_32")
#else
  #include <sys/types.h>
  #include <netinet/in.h>
  #include <sys/socket.h>
  #include <arpa/inet.h>
  #include <netdb.h>
#endif
#include "main.h"

#define DEFAULT_HOST      "localhost"
#define DEFAULT_FTP_PORT  21
#define DEFAULT_FTP_USER  "anonymous"
#define DEFAULT_FTP_PASS  "anonymous@microsoft.com"
#define DEFAULT_SMTP_PORT 25
#define DEFAULT_HTTP_PORT 80
#define DEFAULT_POP_PORT  110
#define DEFAULT_IMAP_PORT 143

int imap_setup(void);
int imap_start(char *host, unsigned short port, char *user, char *pass);
int imap_plain_auth(int sock, char *user, char *pass);

int ftp_setup(void);
int ftp_start(char *host, unsigned short port, char *user, char *pass);
int ftp_plain_auth(int sock, char *user, char *pass);

int pop_setup(void);
int pop_start(char *host, unsigned short port, char *user, char *pass);
int pop_plain_auth(int sock, char *user, char *pass);

int smtp_setup(void);
int smtp_start(char *host, unsigned short port);

int http_setup(void);
int http_start(char *host, unsigned short port);

#endif
