#ifndef _KERNEL_H
#define _KERNEL_H

#include "main.h"

int verbose;

int linux_syscall_setup(void);
int linux_syscall_start(int);

#endif

