#ifndef _MAIN_H
#define _MAIN_H

#include "kernel.h"
#include "protocol.h"
/* add new category headers here */

/* global constants */
#define VERSION "Ostrich v0.1 2005"
#define DEFAULT_RANDOM_SIZE   10000
#define DEFAULT_RESPONSE_SIZE 256

/* global macro definitions*/
#define MAX_INDEX(x) (sizeof (x) / sizeof (char *)) - 2

/* ansi escape sequences */
#define NORMAL     "\033[0m" 
#define COLOR_RECV "\033[43m\033[30m"
#define COLOR_SEND "\033[42m\033[30m"

/* global variables */
int x;

/* menu.c */
void _header(char *title);
void _footer(void);
int main_menu(void);
int protocol_menu(void);
int file_menu(void);
int kernel_menu(void);

/* util.c */
void _clean(void);
void _leave(void);
int _input(void);
int _error(char *fmt, ...);

/* sock.c */
int tcp_connect(char *hostname, unsigned short port);
int ostrich_send(int sock, char *fmt, ...);
int ostrich_recv(int sock, void *buff, size_t msize);
int handle_connect(char *host, unsigned short port);

/* random.c */
int rand_int(int min, int max);
char *rand_string(void);

#endif
