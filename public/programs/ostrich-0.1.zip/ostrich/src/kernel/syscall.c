#ifndef _WIN32
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/syscall.h>
#include "../include/kernel.h"

int linux_syscall_setup(void)
{
  int qtty = 273;

  while (1)
  {
    _clean();
    _header("Linux System Call Configuration");
    if (qtty > 0)
      printf("<1> Quantity: %u\n", qtty);
    else
      printf("<1> Quantity:\n");
    _footer();
    printf("[E] Execute\n");
    printf("[M] Back [Main Menu]\n");
    printf("[B] Back [Protocol Selection]\n");
    printf("[Q] Quit\n");
    printf("\nSelect> ");

    switch (_input())
    {
      case '1': printf("Quantity : ");
                scanf("%d", &qtty);
                break;
      case 'E':
      case 'e': linux_syscall_start(qtty);
                break;
      case 'M': 
      case 'm': main_menu();
      case 'B': 
      case 'b': return 0;
      case 'Q':
      case 'q': _leave();
      default : break;
    }
  }
  return -1;
}

int linux_syscall_start(int qtty)
{
  unsigned int i;
  unsigned int arg1, arg2, arg3, arg4, arg5, arg6, arg7;

  _clean();  

  while (1)
  {
    for (i = 0; i <= qtty; i++)
    {
      arg1 = rand_int(0, qtty);
      arg2 = rand_int(0, qtty);
      arg3 = rand_int(0, qtty);
      arg4 = rand_int(0, qtty);
      arg5 = rand_int(0, qtty);
      arg6 = rand_int(0, qtty);
      arg7 = rand_int(0, qtty);

      switch (i)
      {
        case   1: // exit
        case   2: // fork
        case   3:
        case   4:
        case  11: // execve
        case  22: // unmount
        case  29: // pause
        case  72: //
        case  88: // reboot
        case 109: //
        case 119: //
        case 120: //
        case 173: //
        case 111: //
        case 179: // rt_sigsupend
        case 190: // vfork
        case 252: //
                  continue;
      }      
  
      printf("syscall(%u, %x, %x, %x, %x, %x, %x, %x);\n",
             i, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
      syscall(i, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
    }
  }
  return -1;
}
#endif
