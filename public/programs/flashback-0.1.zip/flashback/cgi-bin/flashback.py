#!C:\Programme\Python25\python.exe -u
# -*- coding: ISO-8859-1 -*-
"""
TOFIX:
- check additional values box, to enter strings AND/OR numbers; use not a struct
- add additional html tags for presenting the images (<img>, <embed>) use eg.: a dropdown menu
- build a better image preloading in the slideshow to calm down the loading time
- look at the charset definition, to enter also numbers eg.: 8000 and to enter also unicode characters in a higher range
- does it make sense to encode also the addidional values with the selected encoding AND/OR compression

TODO:
- add two fields for prepend and append values, and support the sheme: \x41\x41\x41\x41
  include this also into the encoding and compression environment.
- add a method to search also for binary bytes
"""

import cgitb; cgitb.enable()
import cgi
import sys, os
import random
import re, string
import binascii, bz2, zlib
import shutil

sys.path.append("..\\samples")
sys.path.append("tmp")

class HTMLBindings:
    def __init__(self):
        self.QUIT = 1
    
    def error(self, code, message, flag=0):
        e = "<h1>"+code+"</h1>"+message
        if flag == 1:
            print e
            sys.exit(e)
        print e

class flashback(HTMLBindings):
    def __init__(self, user = ""):
        HTMLBindings.__init__(self) # we use data in init of HTMLB here
        self.user = user
        self.counter = 1
        self.diskusage = 0
        self.temp_path = "tmp"
        self.token_list = None
    
    def saveSample(self, filename, data):
        self.file_dst = os.path.join(self.temp_path, self.user)
        if not os.access(self.file_dst, os.F_OK):
            os.makedirs(self.file_dst)
        self.file_src = os.path.join(self.file_dst, filename)
        try:
            f = open(self.file_src, "w+b")
            f.write(data)
            f.close()
        except IOError, err_msg:
            sys.exit("Error: saveSample()\nMessage: "+err_msg)
    
    def readSample(self):
        try:
            f = open(self.file_src, "r+b")
            self.readbuf = f.read()
            f.close()
        except IOError, err_msg:
            sys.exit("Error: readSample()\nMessage: "+err_msg)
    
    def saveAsCopy(self, name, type):
        self.copy_dst = os.path.join(self.file_dst, type)
        if not os.access(self.copy_dst, os.F_OK):
            os.makedirs(self.copy_dst)
        self.copy_src = os.path.join(self.copy_dst, name)
        try:
            f = open(self.copy_src, "w+b")
            f.write(self.readbuf)
            f.close()
        except IOError, err_msg:
            sys.exit("Error: saveAsCopy()\nMessage: "+err_msg)
        self.diskusage += len(self.readbuf)

    def cleanInput(self, data, badchrs=["|",";","<",">","&","?","'","~",]):
        tmp = ""
        for ch in badchrs: tmp = data.strip(ch)
        if len(tmp) < len(data): self.exit("String contained bad characters")
        return tmp

    def delUserCache(self):
        delpath = os.path.join(self.temp_path, self.user)
        if os.access(delpath, os.F_OK):
            shutil.rmtree(delpath)
            print "Previous files were removed!"

    def getFiletype(self, name):
        return name.rsplit(".")[1]
    
    def splitStrToInt(self, data, token=":"):
        return [int(i) for i in data.split(token)]
    
    def splitStrToStr(self, data, token=","):
        return [str(i) for i in data.split(token)]

    def joinIntToStr(self, data, token=":"):
        return token.join(([str(i) for i in data]))
    
    def insertBytes(self, content, offset, bytes):
        return content[:offset] + bytes + content[offset:]
    
    def replaceBytes(self, content, offset, bytes):
        return content[:offset] + bytes + content[offset+len(bytes):]

    def setCharset(self, charset, length=1, randomize=0):
        charsets = self.splitStrToStr(charset)
        charsbox = []
        
        for set in charsets:
            char_min, char_max = self.splitStrToInt(set)
        
            if char_min < 0  : char_min = 0
            if char_min > 255: char_min = 65
            
            if char_max < 0  : char_max = 255
            if char_max > 255: char_max = 255
            
            charsbox.append([char_min, char_max])
        
        if randomize == 1:
            for char_min, char_max in charsbox:
                str = ""
                for le in range(length):
                    str += chr(random.randint(char_min, char_max))
                yield str
        else:
            for char_min, char_max in charsbox:
                for char in range(char_min, char_max+1):
                    yield chr(char)
            
    
    def setIteration(self, iteration):
        len_min, len_max, len_add = self.splitStrToInt(iteration)
        
        if len_min < 0                : len_min = 0
        if len_min > len(self.readbuf): len_min = 0
        
        if len_max < 0                : len_max = len(self.readbuf)
        if len_max > len(self.readbuf): len_max = len(self.readbuf)
        
        if len_add < 0                : len_min = 4
        if len_add > len(self.readbuf): len_min = 4

        for length in range(len_min, len_max, len_add):
            yield length

    def setOffsets(self, offsets, tokens):
        offset_min, offset_max, offset_add = self.splitStrToInt(offsets)
        
        if offset_min  < 0                : offset_min = 0
        if offset_min  > len(self.readbuf): offset_min = 0
        
        if offset_max  < 0                : offset_max = len(self.readbuf)
        if offset_max  > len(self.readbuf): offset_max = len(self.readbuf)
        
        if offset_add  < 0                : offset_add = 4
        if offset_add  > len(self.readbuf): offset_add = 4
        
        if tokens:
            self.getTokens(tokens, offset_min, offset_max)
            for start, end in self.token_list:
                yield end # (start,end) for after/before -> insert,replace
        else:
            for offset in range(offset_min, offset_max, offset_add):
                yield offset

    def getTokens(self, tokens, offset_min, offset_max):
        tokens = self.splitStrToStr(tokens)
        regchrs = ["?", "\\", "$", "^", "+", ".", "*", ",", "|", "(", ")", "[", "]"]
        
        if len(tokens) == 0:
            return
        
        self.token_list = list()

        for token in tokens:
            try:
                if token in regchrs:
                    token = "\\"+token
                occurence = re.finditer(token, self.readbuf[offset_min:offset_max])
                for match in occurence:
                    self.token_list.append([match.start(), match.end()])
            except TypeError:
                continue

        if len(self.token_list) == 0:
            self.error("Error", "No tokens were found!", self.QUIT)

        self.token_list.sort()
        
    def setEncode(self, type, bytes):
        type = type.lower()
        if type == "ascii": return bytes
        try:
            return unicode(bytes).encode(type)
        except LookupError:
            return bytes
    
    def setCompression(self, type, bytes):
        type = type.lower()
        if   type == "base64":   return binascii.b2a_base64(bytes)[:-1]
        elif type == "uuencode": return binascii.b2a_uu(bytes)[:-1]
        elif type == "bz2":      return bz2.compress(bytes)
        elif type == "gzip":     return zlib.compress(bytes)
        elif type == None:       return bytes
        else:                    return bytes

    def getOutputString(self, charset, iteration, randomize=0):
        if randomize == 0:
            for char in self.setCharset(charset):
                for length in self.setIteration(iteration):
                    yield char*length
        else:
            for length in self.setIteration(iteration):
                for str in self.setCharset(charset, length, 1):
                    yield str

    def convert(self, value):
        result = ""
        while value != "":
            two = value[:2]
            if two != "0x" and two != "\\x":
                result += chr(int(two,16))
            value = value[2:]
        return result

    def addStringFormat(self, values, bytes, flag):
        if flag == 0 or flag == "append":
            for value in values.split("\r\n"): yield bytes+self.convert(value)
        elif flag == 1 or flag == "prepend":
            for value in values.split("\r\n"): yield self.convert(value)+bytes

    def getOutputLocation(self, offsets, tokens):
        for offset in self.setOffsets(offsets, tokens):
            yield offset
    
    def setOutputBuffer(self, offset, bytes, method):
        if method == "replace":
            self.readbuf = self.replaceBytes(self.readbuf, offset, bytes)
        elif method == "insert":
            self.readbuf = self.insertBytes(self.readbuf, offset, bytes)
    
    def setFilename(self, extension):
            self.filename = str(self.counter)+"."+extension
            self.counter += 1

    def setTemplate(self, opts, template):
        return string.Template(template).substitute(opts)

## Configuration
html_form = cgi.FieldStorage()
# user data
user      = cgi.os.environ["REMOTE_ADDR"]
file      = html_form["file"]
# string generation
charset   = html_form["charset"].value
randflag  = html_form.getvalue("random") or 0
iteration = html_form["iteration"].value
enctype   = html_form["enctype"].value
comtype   = html_form["comtype"].value
value_add = html_form["value_add"].value
value_loc = html_form["value_loc"].value
# target location
offsets   = html_form["offsets"].value
tokens    = html_form["tokens"].value
method    = html_form["method"].value
delcache  = html_form.getvalue("delcache")


print "Content-Type: text/html"
print

# The main part
flash = flashback(user)
if delcache: flash.delUserCache()
if not file.filename: flash.error("Error", "No file was given!", flash.QUIT)
flash.saveSample(flash.cleanInput(file.filename), file.value)
flash.readSample()
for location in flash.getOutputLocation(offsets, tokens):
    for bytes in flash.getOutputString(charset, iteration, randflag):
        bytes = flash.setEncode(enctype, bytes)
        bytes = flash.setCompression(comtype, bytes)
        for bytes in flash.addStringFormat(value_add, bytes, value_loc):
            flash.setOutputBuffer(location, bytes, method)
            flash.setFilename(flash.getFiletype(file.filename))
            flash.saveAsCopy(flash.filename, flash.getFiletype(file.filename))
            flash.readSample()

# HTML stats
template_stats = """
<table width="259" border="0" cellpadding="3" cellspacing="1">
  <tr>
    <td colspan="2" bgcolor="#6666FF"><span class="title">Statistic</span></td>
  </tr>
  <tr>
    <td width="95" bgcolor="#336699"><span class="text">Files:</span></td>
    <td width="143">$files</td>
  </tr>
  <tr>
    <td bgcolor="#336699"><span class="text">Disk:</span></td>
    <td>$diskbytes bytes</td>
  </tr>
</table>
<br />
"""
template_stats = flash.setTemplate(dict(files     = flash.counter-1,
                                        diskbytes = flash.diskusage),
                                   template_stats)

# HTML slideshow
template_sshow = """
    <html>
        <head>
            <title>Flashback</title>
            <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
            <META HTTP-EQUIV="Expires" CONTENT="-1">
            <style type="text/css">
                .text {font-family: Verdana, Arial, Helvetica, sans-serif; 
                           font-size: 12px; color:#FFFFFF}
                .title {
                        font-family: Verdana, Arial, Helvetica, sans-serif;
                        font-weight: bold; color: #FFFFFF; font-size: 12px;
                }
            </style>
            <script language="JavaScript">
            <!-- 
                var interval = 90; 
                var random_display = 0;
                var image_dir = \"$imagepath\";
                var ImageNum = 0;
                imageArray = new Array();
                
                $imagetable
                
                var number_of_image = imageArray.length;
                
                function imageItem(image_location) {
                    this.image_item = new Image();
                    this.image_item.src = image_location;
                }
                function get_ImageItemLocation(imageObj) {
                    return(imageObj.image_item.src)
                }
                function randNum(x, y) {
                    var range = y - x + 1;
                    return Math.floor(Math.random() * range) + x;
                }
                function getNextImage() {
                    if (random_display) {
                        ImageNum = randNum(0, number_of_image-1);
                    }
                    else {
                        ImageNum = (ImageNum+1) % number_of_image;
                    }
                    var new_image = get_ImageItemLocation(imageArray[ImageNum]);
                    return(new_image);
                }
                
                function getPrevImage() {
                    ImageNum = (ImageNum-1) % number_of_image;
                    var new_image = get_ImageItemLocation(imageArray[ImageNum]);
                    return(new_image);
                }
                
                function prevImage(place) {
                    var new_image = getPrevImage();
                    document[place].src = new_image;
                    window.status = new_image;
                }
                
                function lastImage() {
                    window.status = getPrevImage();
                }
                
                function rotateImage(place) {
                    var new_image = getNextImage();
                    document[place].src = new_image;
                    var recur_call = "rotateImage('"+place+"')";
                    timerID = setTimeout(recur_call, interval);
                    window.status = new_image;
                }
            //   -->
            </script>
        </head>
        <body>
            $template_stats
            <input onClick="rotateImage('rImage')" type="submit" value="Start" /> 
            <input onClick="clearTimeout(timerID); lastImage()" type="submit" value="Stop" />
            <input onClick="prevImage('rImage'); clearTimeout(timerID)" type="submit" value="Back" /> 
            <input onClick="rotateImage('rImage'); clearTimeout(timerID)" type="submit" value="Next" />
            <br /><hr /><br /><br /><br />
            $displaytag
        </body>
    </html>
"""

imagetable = ""
for nr in range(1, flash.counter):
    imagetable += "imageArray[ImageNum++] = new imageItem(image_dir + \""+str(nr)+"."+flash.getFiletype(file.filename)+"\");\n\t"
imagepath  = "../"+flash.temp_path+"/"+flash.user+"/"+flash.getFiletype(file.filename)+"/"
displaytag = '<img src="" name="rImage" />'

print flash.setTemplate(dict(imagetable     = imagetable,
                             imagepath      = imagepath,
                             template_stats = template_stats,
                             displaytag     = displaytag),
                        template_sshow)
