#!/usr/bin/env python
import random, re, socket

"""
HTTP Response Header Fields
===========================
RFC: 2616
Author: posidron
"""

# Packet Definition Structure
# ===========================
# x[0][n] = Example
# x[1][n] = User defined

status_line = {
    "100":[["Continue"],["<*>"]],
    "101":[["Switching Protocols"],["<*>"]],
    "200":[["OK"],["<*>"]],
    "201":[["Created"],["<*>"]],
    "202":[["Accepted"],["<*>"]],
    "203":[["Non-Authoritative Information"],["<*>"]],
    "204":[["No Content"],["<*>"]],
    "205":[["Reset Content"],["<*>"]],
    "206":[["Partial Content"],["<*>"]],
    "300":[["Multiple Choices"],["<*>"]],
    "301":[["Moved Permanently"],["<*>"]],
    "302":[["Found"],["<*>"]],
    "303":[["See Other"],["<*>"]],
    "304":[["Not Modified"],["<*>"]],
    "305":[["Use Proxy"],["<*>"]],
    "307":[["emporary Redirect"],["<*>"]],
    "400":[["Bad Request"],["<*>"]],
    "401":[["Unauthorized"],["<*>"]],
    "402":[["Payment Required"],["<*>"]],
    "403":[["Forbidden"],["<*>"]],
    "404":[["Not Found"],["<*>"]],
    "405":[["Method Not Allowed"],["<*>"]],
    "406":[["Not Acceptable"],["<*>"]],
    "407":[["Proxy Authentication Required"],["<*>"]],
    "408":[["Request Time-out"],["<*>"]],
    "409":[["Conflict"],["<*>"]],
    "410":[["Gone"],["<*>"]],
    "411":[["Length Required"],["<*>"]],
    "412":[["Precondition Failed"],["<*>"]],
    "413":[["Request Entity Too Large"],["<*>"]],
    "414":[["Request-URI Too Large"],["<*>"]],
    "415":[["Unsupported Media Type"],["<*>"]],
    "416":[["Requested range not satisfiable"],["<*>"]],
    "417":[["Expectation Failed"],["<*>"]],
    "500":[["Internal Server Error"],["<*>"]],
    "501":[["Not Implemented"],["<*>"]],
    "502":[["Bad Gateway"],["<*>"]],
    "503":[["Service Unavailable"],["<*>"]],
    "504":[["Gateway Time-out"],["<*>"]],
    "505":[["HTTP Version not supported"],["<*>"]],
    ""   :[["has no reason"],["<*>"]],
}

general_hdr = {
    "Cache-Control":[[
        "public","private=","no-cache","no-store","no-transform","must-revalidate",
        "proxy-revalidate","max-age=seconds","s-maxage=seconds"],
        ["<*>"]],
    "Connection":[["close"],["<*>"]],
    "Data":[["Tue, 15 Nov 1994 08:12:31 GMT"],["<*>"]],
    "Pragma":[["no-cache"],["<*>"]],
    "Trailer":[[""],["<*>"]],
    "Transfer-Encoding":[["chunked", "identity", "gzip", "compress"],["<*>"]],
    "Upgrade":[["HTTP/2.0, SHTTP/1.3, IRC/6.9, RTA/x11"],["<*>"]],
    "Via":[["1.0 fred, 1.1 nowhere.com (Apache/1.1)"],["<*>"]],
    "Warning":[["110 Response is stale",
                "111 Revalidation failed",
                "112 Disconnected operation",
                "113 Heuristic expiration",
                "199 Miscellaneous warning",
                "214 Transformation applied",
                "299 Miscellaneous persistent warning"],["<*>"]],
    "":[[""],["<*>"]],
}

response_hdr = {
    "Accept-Range":[["bytes"],["<*>"]],
    "Age":[["120"],["<*>"]],
    "ETag":[['W/"xyzzy"'],
            ["<*>"]],
    "Location":[["http://localhost:80"],
                ["<*>"]],
    "Proxy-Authentication":[["xhHmjuIwuHwhvwpo"],["<*>"]],
    "Retry-After":[["Fri, 31 Dec 1999 23:59:59 GMT"],
                   ["<*>"]],
    "Server":[["CERN/3.0 libwww/2.17"],["<*>"]],
    "Vary":[["*"],["<*>"]],
    "WWW-Authenticate":[["bmnHdFmAdePoMneur"],["<*>"]],
    "":[["<*>"],["<*>"]],
}

entity_hdr = {
    "Allow":[["GET", "HEAD", "PUT"],
             ["<*>"]],
    "Content-Encoding":[["gzip"],["<*>"]],
    "Content-Language":[["da", "mi, en", "en, en-US, en-cockney, i-cherokee, x-pig-latin"], ["<*>"]],
    "Content-Length":[["423"],["<*>"]], # !!!
    "Content-Location":[["http://localhost:80"],["<*>"]],
    "Content-MD5":[[""],["<*>"]], # !!!
    "Content-Range":[["bytes 21010-47021/47022"],["<*>"]],
    "Content-Type":[["text/html; charset=ISO-8859-4"],["charset=<*>"]],
    "Expires":[["Thu, 01 Dec 1994 16:00:00 GMT"],["<*>"]],
    "Last-Modified":[["Tue, 15 Nov 1994 12:45:26 GMT"],["<*>"]],
    "":[[""],["<*>"]],
}

class input:
    def __init__(self):
        self.TOKENS = {
            "<sp>"    : self.sp,
            "<crlf>"  : self.crlf,
            "<int>"   : self.integer,
            "<sint>"  : self.signed_integer,
            "<uint>"  : self.unsigned_integer,
            "<*>"     : self.switch,
            "<sstr>"  : self.strict_string,
            "<rstr>"  : self.random_string,
            "<char>"  : self.random_char,
        }
        
        self.min_len = 0
        self.max_len = random.randint(0, 9999)
        self.default_ch = 65
        self.min_ch = 32
        self.max_ch = 172

    def switch(self):
        "Strict or random string"
        if random.randint(0, 1) == 0:
            return self.strict_string()
        else:
            return self.random_string()

    def sp(self):
        "Whitespace character"
        return " "

    def crlf(self):
        "Carriage return and line feed character"
        return "\r\n"

    def random_char(self):
        "Single random character"
        return chr(random.randint(0, 172))
    
    def integer(self):
        "Random signed or unsigned integer"
        if random.randint(0, 1) == 0:
            return self.signed_integer()
        else:
            return self.unsigned_integer()
        
    def signed_integer(self):
        "Signed integer"
        numbers = [-2147483648, -2147483658, -10, -1]
        return str(numbers[random.randint(0, len(numbers)-1)])
    
    def unsigned_integer(self):
        "Unsigned integer"
        numbers = [2147483647, 2147483657, 10, 1]
        return str(numbers[random.randint(0, len(numbers)-1)])
    
    def strict_string(self):
        "Strict (single character) string"
        s = ""
        for char in xrange(self.min_len, self.max_len):
            s += chr(self.default_ch)
        return s

    def random_string(self):
        "Random (multiple character) string"
        s = ""
        for char in xrange(self.min_len, self.max_len):
            s += chr(random.randint(self.min_ch, self.max_ch))
        return s

class Butler(input):
    def __init__(self):
        input.__init__(self)

    def replace_token(self, token, string):
        result = ""
        TokenResult = re.finditer(token, string)
        start = 0
        for occurence in TokenResult:
            bracket = string[start:occurence.end()]
            result += bracket.replace(token, self.TOKENS[token]())
            start   = occurence.end()
        result += string[start:]
        return result

    def parse_string(self, string):
        for token in self.TOKENS.keys():
            string = self.replace_token(token, string)
        return string


def getHTTPResponseHeader(header, max_syntax_opts=1):
    def selectByRandom(max, min=0):
        return random.randint(min, max)
    field = header.keys()[selectByRandom(len(header.keys())-1)]
    syntax = selectByRandom(max_syntax_opts)
    value  = selectByRandom(len(header[field][syntax])-1)
    return (field, syntax, value)

def getRandomN(hdr):
    return random.randint(0, len(hdr.keys()))

def getHTTPMessage(case=0):
    return '\r\n'\
           '<html><head><meta http-equiv="refresh" content="0; URL=http://127.0.0.1:80/" /></head>'\
           '<body>Test case: %d</body>'\
           '<head><META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">'\
           '</head></html>' % case

def getHTTPResponse(case=0):
    rebuffer = ""
    dupcheck = []
    response = Butler()

    field, syntax, value = getHTTPResponseHeader(status_line, 1)
    rebuffer += "HTTP/1.1"+" "+field+" "+response.parse_string(status_line[field][syntax][value]) + "\r\n"
    
    for max_items in range(getRandomN(general_hdr)):
        field, syntax, value = getHTTPResponseHeader(general_hdr, 1)
        if field not in dupcheck:
            rebuffer += field+":"+" "+response.parse_string(general_hdr[field][syntax][value]) + "\r\n"
            dupcheck.append(field)

    for max_items in range(getRandomN(response_hdr)):
        field, syntax, value = getHTTPResponseHeader(response_hdr, 1)
        if field not in dupcheck:
            rebuffer += field+":"+" "+response.parse_string(response_hdr[field][syntax][value]) + "\r\n"
            dupcheck.append(field)
    
    for max_items in range(getRandomN(entity_hdr)):
        field, syntax, value = getHTTPResponseHeader(entity_hdr, 1)
        if field not in dupcheck:
            rebuffer += field+":"+" "+response.parse_string(entity_hdr[field][syntax][value]) + "\r\n"
            dupcheck.append(field)

    return rebuffer


s = socket.socket()
s.bind(("127.0.0.1", 80))
s.listen(5)

counter = 0

while 1:
    client, hostid = s.accept()
    print "Client", hostid[0]+":"+str(hostid[1]), "connected!"
    response  = getHTTPResponse()
    response += getHTTPMessage(counter)
    print response
    client.send(response)
    client.close()
    counter += 1

    