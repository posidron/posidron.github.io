# -*- coding: ISO-8859-1 -*- 
__version__ = "Flashback v1.0"

import CGIHTTPServer
import SocketServer
import webbrowser
import os, socket

os.chdir(".")

class MyRequestHandler(CGIHTTPServer.CGIHTTPRequestHandler):
    def is_cgi(self):
        base, filename = os.path.split(self.path)
        if ".py" in filename:
            if "?" in filename:
                os.environ["SCRIPT_FILENAME"] = filename.split("?",1)[0]
            else:
                os.environ["SCRIPT_FILENAME"] = filename
            
            os.environ["DOCUMENT_ROOT"] = os.getcwd()
            self.cgi_info = base, filename
            return True
            

class MyThreadingServer(SocketServer.ThreadingTCPServer):
    allow_reuse_addr = 1
    
    def __init__(self, server_address, request_handler, AllowIPs):
        SocketServer.ThreadingTCPServer.__init__(self, server_address, request_handler)
        self.AllowIPs = [mask.split(".") for mask in AllowIPs]
    
    def server_bind(self):
        SocketServer.ThreadingTCPServer.server_bind(self)
        host, self.server_port = self.socket.getsockname()[:2]
        self.server_name = socket.getfqdn(host)
    
    def verify_request(self, dummy, client_address):
        def CheckIP(mask):
            for mask_part, ip_part in zip(mask, ip):
                if mask_part != ip_part and mask_part != "*":
                    return False
            return True
        
        ip = client_address[0].split(".")
        
        for mask in self.AllowIPs:
            if CheckIP(mask):
                return True
        
        print "IP [%s] not allowed!" % client_address
        return False

def StartCGIServer(ListenPort, AllowIPs):
    httpd = MyThreadingServer(("", ListenPort), MyRequestHandler, AllowIPs)
    webbrowser.open("http://127.0.0.1:%d" % ListenPort)
    httpd.serve_forever()


if __name__ == "__main__":
    StartCGIServer(ListenPort = 8080,
                   AllowIPs = ("127.0.0.1", "192.168.*.*")
                  )
    