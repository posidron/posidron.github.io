Pre-configuration
----------------
- be sure port 8080 is not in use
- activate Java Script in your Browser


Configuration
-------------

Sample file
- user defined image file, size depend on max disk size.

Charset (min, max)
- comma seperated value container.

String iteration (min, max, step)
- defines the string length

Encoding, Compression
- sets additional string operations

Additional values
- defines additional values which can be append or prepend to the produced string.

Offset specifications (min, max, step)
- defines the target location. -1 defines EOF

Method
- replace string or insert string after known characters. Leave empty if not needed.

Cache
- deletes all generated files of the actual user/ip.
- delete also your internal Browser cache, in the next session!


Demonstration for Opera
-----------------------

1 - Start Soja.py.
2 - Select "Flashback"
3 - Select "samples/1x1-low.jpg" as sample image
4 - delete the content in "Additional values"
5 - Click Start
6 - Wait
7 - Click Start