/*
*****************************************************************************
* picasso - picasso.c
* Copyright (C) 2005 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/

#include "include/picasso.h"

int main(int argc, char **argv) {
  int opt;
  FILE *estream;
  FILE *xstream;
  FILE *cstream;
  char *emb_path    = NULL;
  char *out_path    = NULL;
  char *ext_path    = NULL;
  char *hexdump_str = NULL;
  char *hexdump_bin = NULL; 
  char *strsdat     = NULL;
  char *strfdat     = NULL;
  char *imghdr_path = NULL;
  ulong isize, txtlen = 0;
  ulong mem_blk = 0;
  ulong mem_off = 0;
  long offset;
  
  while((opt = getopt(argc, argv, "e:x:d:o:h:v:")) != -1) {
    switch(opt) {
      case 'e':
	  emb_path = optarg;
        break;
      case 'x':
	  ext_path = optarg;
	break;
      case 'd':
        if(strncmp(optarg, "s", 1) == 0) {
	  strsdat = argv[optind];
	}
	else if(strncmp(optarg, "f", 1) == 0) {
	  strfdat = argv[optind];
	}
	break;
      case 'h':
        if(strncmp(optarg, "s", 1) == 0) {
	  hexdump_str = argv[optind];
	}
	else if(strncmp(optarg, "b", 1) == 0) {
	  hexdump_bin = argv[optind];
	
	  ++optind;
          if(optind == argc)
	    break;  /* bin is last argument,
	
	  mem_blk, mem_off = 0 */
	
	  if(strncmp(argv[optind], "-", 1) == 0)
	    break;  /* new flag, break */
											       
	  if(optind < argc) {
	    mem_blk = atoi(argv[optind]);
	  }
															       
	  ++optind;
	  if(optind == argc)
	    break;  /* first optional arg,
	             was the last one */
	
	  if(strncmp(argv[optind], "-", 1) == 0)
	    break;  /* new flag, break */
																									    
	  if(optind <= argc) {
	    mem_off = atoi(argv[optind]);
	    break;  /* second optional arg */
	  }
       }
       break;	
       case 'o':
         out_path = optarg;
	break;
      case 'v':
        imghdr_path = optarg;
        break;
      default:
        err(ERR_SYNTAX);
        print_help();
	break;
    }
  }
  
  printf("\nStarting Picasso "VERSION" ("RELEASE")\n\n");
  
   
  if(strsdat != NULL) {
    txtlen = strlen(strsdat);
  }
  
  if(strfdat != NULL) {
    xstream = fopen(strfdat, "rb");
    
    if(xstream == NULL) {
      err(ERR_NO_FILE);
      return -1;
    }

    txtlen = sizeof_regfl(strfdat);

    if(txtlen <= 0) {
      err(ERR_EMPTY_FILE);
      fclose(xstream);
      return -2;
    }

    strsdat = rstream_content(xstream, txtlen);
    
    if(strsdat == NULL) {
      err(ERR_MALLOC);
      return -3;
    }
    
    fclose(xstream);
  }
  
  
  if(imghdr_path != NULL) {
    read_bmp_hdr(imghdr_path);
  }
  
  if(hexdump_bin != NULL) {
    mk_hexdump_bin(hexdump_bin, mem_blk, mem_off);
  }
  
  if(hexdump_str != NULL) {
    mk_hexdump_str(hexdump_str);
  }
  
  if((emb_path != NULL) && (out_path != NULL)) {
    estream = fopen(emb_path, "rb");
  
    if(estream == NULL) {
      err(ERR_NO_FILE);
      return -1;
    }
    
    isize = sizeof_image(emb_path);
    
    if(isize < 0) {
      err(ERR_EMPTY_FILE);
      fclose(estream);
      return -2;
    }
    
    offset = image_type(estream);
    check_offset(offset);
    
    if(txtlen >= ((isize - offset) / 8)) {
      printf(ERR_TXT_LONG);
      return -3;
    }
    
    if(txtlen == 0) {
      err(ERR_TXT_SMALL);
      return -4;
    }
    cstream = fopen(out_path, "wb");
    
    if(cstream == NULL) {
      fclose(estream);
      return -4;    
    }

    printf("picasso: a copy of the origin file will made.\n");
    copy_image(estream, cstream);
    
    printf("picasso: the data will now added to the file.\n"); 
    import_image(estream, cstream, offset, strsdat);
    
    printf("picasso: job is done.\n");
    if(strfdat != NULL) {
      free(strsdat);
    }
  }
  else if(ext_path != NULL) {
    xstream = fopen(ext_path, "rb");
    
    if(xstream == NULL) {
      err(ERR_NO_FILE);
      return -1;
    }
    
    offset = image_type(xstream);
    check_offset(offset);
    
    printf("picasso: the image will now searched for hidden data.\n");    
    printf("\n   data: ");
    export_image(xstream, offset, txtlen);
    printf("\npicasso: job is done.\n");
  }
  
  printf("\n");
  return 0;
}

size_t sizeof_image(const char *image) {
  struct stat buf;
  
  if(stat(image, &buf) != -1) {
    return buf.st_size;
  }
  else {
    return -1;
  }
}

size_t sizeof_regfl(const char *regfl) {
  struct stat buf;

  if(stat(regfl, &buf) != -1) {
    return buf.st_size;
  }
  else {
    return -1;
  }
}

void copy_image(FILE *oimg, FILE *nimg) {
  int ch;

  rewind(oimg);
  rewind(nimg);

  while(!(feof(oimg))) {
    ch = fgetc(oimg);
    fputc(ch, nimg);
  }
}

int image_type(FILE *image) {
  int i;
  char type[15];

  for(i = 0; i <= 15; i++) {
    (int)*(type+i) = fgetc(image);
  }
  if(strncmp(BITMAP, type, 2) == TRUE) {
    return BITMAP_JMP;
  }
  else if(strncmp(JPEG, type+6, 4) == TRUE) {
    return JPEG_JMP;
  }
  else if(strncmp(GIF, type, 3) == TRUE) {
    return GIF_JMP;
  }
  else if(strncmp(PNG, type+1, 3) == TRUE) {
    return PNG_JMP;
  }
  else {
    return -1;
  }
}

void check_offset(int offset) {
  switch(offset) {
    case BITMAP_JMP:
      printf("picasso: the Bitmap format was detected.\n");
      printf("         Unclear wether Windows or OS/2 format.\n");
      break;
    case JPEG_JMP:
      printf("picasso: the JPEG format was detected.\n");
      printf("         at the moment picasso has no jobs for this format.\n");
      exit(1);
   case GIF_JMP:
     printf("picasso: the GIF format was detected.\n");
     printf("         at the moment picasso has no jobs for this format.\n");
     exit(1);
   case PNG_JMP:
     printf("picasso: the PNG format was detected.\n");
     printf("         at the moment picasso has no job for this format.\n");
     exit(1);
   default:
     printf("warning: the given format is not supported!\n");
     exit(1);
   }
}

char *rstream_content(FILE *stream, size_t size) {
  char *data;

  data = malloc(size);
  
  if(data == NULL) {
    return NULL;
  }
  
  fread(data, 1, size, stream);
 
  return data;
}

void print_help() {
  printf("\npicasso "VERSION" ("RELEASE")\n\n"
         "  -e  <file>             the raw image file\n"
	 "  -x  <file>             the crypted image file\n"
	 "  -ds <string>           the to crypted text\n"
	 "  -df <file>             the to crypted text file\n"
	 "  -o  <file>             the output image file\n"
	 "  -hs <string>           hexdump for strings\n"
	 "  -hb <bytes> <offset>   hexdump for files\n"
	 "  -v  <file>             header output\n"
	 "\nFor further information look at the manpage of picasso!\n\n");
  exit(0);
}