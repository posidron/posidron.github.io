/*
*****************************************************************************
* picasso - imghdr.c
* Copyright (C) 2004 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/


#include "include/imghdr.h"

int read_bmp_hdr(const char *img_path) {
  FILE *img;

  img = fopen(img_path, "r");

  if(img == NULL)
    return -1;

  fread(&bitmap, 1, sizeof(struct hdr_bmp), img);

  printf("File Type.......:  %c%c\n", bitmap.file_type[0], bitmap.file_type[1]);
  printf("File Size.......:  %d Bytes\n", bitmap.file_size);
  printf("Header Chunk....:  %d Bytes\n", bitmap.chunk);
  printf("Header Size:....:  %d Bytes\n", bitmap.hdr_size);
  printf("Body Header Size:  %d Bytes\n", bitmap.hdr_len_new);
  printf("Image Width.....:  %d Pixel\n", bitmap.img_width);
  printf("Image High......:  %d Pixel\n", bitmap.img_high);
  printf("Number o. Layers:  %d\n", bitmap.layer_nbr);
  printf("Color Depth.....:  %d Bits/Pixel\n", bitmap.color_depth);
  printf("Compression.....:  %d\n", bitmap.comp_chunk);
  printf("File Size w. H..:  %d Bytes\n", bitmap.raw_hdr_size);
  printf("Hor. Resolution.:  %d Pixel\n", bitmap.hor_res);
  printf("Ver. Resolution.:  %d Pixel\n", bitmap.ver_res);
  printf("Used Colors.....:  %d\n", bitmap.used_colors);
  printf("Important Colors:  %d\n", bitmap.important_colors);

  fclose(img);

  return 0;
}
