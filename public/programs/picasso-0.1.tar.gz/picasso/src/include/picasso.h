/*
*****************************************************************************
* picasso - picasso.h
* Copyright (C) 2005 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/

#ifndef H_PICASSO
#define H_PICASSO

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#ifdef __unix__
  #include <unistd.h>
  #include <sys/stat.h>
  #include <sys/types.h>
#elif __MSDOS__ || __WIN32__ || _MSC_VER
  #include <io.h>
  #include <sys\stat.h>
#endif

#include "mkdump.h"
#include "imghdr.h"
#include "bmp.h"
#include "errmsg.h"

enum { TRUE, FALSE };
	  
#define BITMAP "BM"
#define BITMAP_JMP 55

#define JPEG   "JFIF"
#define JPEG_JMP   0

#define GIF    "GIF"
#define GIF_JMP  1

#define PNG    "PNG"
#define PNG_JMP 2

#define VERSION "0.1"
#define RELEASE "www.tripbit.org/releases/picasso/"

int image_type(FILE *);
size_t sizeof_image(const char *);
size_t sizeof_regfl(const char *);
char *rstream_content(FILE *, size_t);
void copy_image(FILE *, FILE *);
void check_offset(int);
void print_help();
#endif
