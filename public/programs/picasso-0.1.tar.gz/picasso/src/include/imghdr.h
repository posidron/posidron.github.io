/*
*****************************************************************************
* picasso - imghdr.h
* Copyright (C) 2005 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/

#ifndef H_IMGHDR
#define H_IMGHDR

#include "picasso.h"

#pragma pack(1)
struct hdr_bmp {
  char file_type[2];     // 2 bytes
  uint file_size;        // 4 bytes
  uint chunk;            // 4 bytes
  uint hdr_size;         // 4 bytes
  uint hdr_len_new;      // 4 bytes
  uint img_width;        // 4 bytes
  uint img_high;         // 4 bytes
  short layer_nbr;       // 2 bytes
  short color_depth;     // 2 bytes
  uint comp_chunk;       // 4 bytes
  uint raw_hdr_size;     // 4 bytes
  uint hor_res;          // 4 bytes
  uint ver_res;          // 4 bytes
  uint used_colors;      // 4 bytes
  uint important_colors; // 4 bytes
}bitmap;
#pragma pack()

int read_bmp_hdr(const char *);

#endif
