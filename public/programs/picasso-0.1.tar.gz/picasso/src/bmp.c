/*
*****************************************************************************
* picasso - bmp.c
* Copyright (C) 2005 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*****************************************************************************
*/

#include "include/bmp.h"

void export_image(FILE *xstream, int offset, int datlen) {
  ulong tbytepos;
  ulong ibytepos, ibyte, i;
  char ch;

  fseek(xstream, (long)offset, SEEK_SET);

  datlen = fgetc(xstream);
  datlen -= sizeof(int);

  for(tbytepos = datlen; tbytepos > 0; tbytepos--) {
    for(ch = 0, ibytepos = 8; ibytepos > 0; ibytepos--) {
      ibyte = fgetc(xstream);
      i = ibyte % 2;
      ch = ch | ( i << (8 - ibytepos));
    }
    printf("%c", ch);
  }
  printf("\n");
  fclose(xstream);
}


void import_image(FILE *oimg, FILE *cimg, int offset, char *text) {
  ulong tbytepos;
  ulong ibytepos, ibyte;
  ulong i, wbyte;
  int tsize = 0;
  
  fseek(oimg, (long)offset, SEEK_SET);
  fseek(cimg, (long)offset, SEEK_SET);
  
  tsize += sizeof(int) + strlen(text);      
  fputc(tsize, cimg);

  for(tbytepos = 0; tbytepos < tsize; tbytepos++) {
    for(ibytepos = 0; ibytepos < 8; ibytepos++) {
      ibyte = fgetc(oimg);
      i = ibyte;
      if(text[tbytepos] & (1 << ibytepos)) {  // 1
        wbyte = ibyte | 1;
        fputc(wbyte, cimg);
      }
      else {  // 0
         if(i % 2) {
           wbyte = ibyte | 1;
         }
         if(!(i % 2)) {
           wbyte = ibyte;
         }
         fputc(wbyte, cimg);
      }
    }
  }

  fclose(oimg);
  fclose(cimg);
}
