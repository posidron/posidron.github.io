/*
******************************************************************************** 
* picasso - mkdump.c
* Copyright (C) 2005 posidron <posidron@tripbit.org>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
********************************************************************************
*/

#include "include/mkdump.h"

int mk_hexdump_str(const char *str) {
  short int cell = 16;
  ulong oset = 0, cind = 0;
  ulong hpos = 0, apos = 0;
  size_t mlen = strlen(str);

  printf("%08lx  ", oset);
  while(hpos <= mlen) {
    for(cind = 0; cind < cell && hpos <= mlen; cind++, hpos++) {
      printf("%02x ", (unsigned char)*(str+hpos));
      if(cind == 7) {
        printf("  ");
      }
    }
    if(cind < cell) {
      if(cind <= 7) {
        for(; cind < 8; cind++) {
          printf("   ");
        }
        printf("  ");
      }
      for(; cind <= cell-1; cind++) {
          printf("   ");
      }
    }
    printf("  |");
    for(cind = 0; cind < cell && apos <= mlen; cind++, apos++) {
      if(isprint((int)*(str+apos))) {
        printf("%c", (unsigned char)*(str+apos));
      }
      else {
        printf(".");
      }
    }
    printf("|\n");
    printf("%08lx  ", oset+=cell);
  }
  printf("\n");
  
  return 0;
}

int mk_hexdump_bin(const char *path, ulong mem_size, ulong oset) {
  FILE *bin;
  char *bin_mem;
  short int cell = 16;
  ulong cind = 0, hpos = 0, apos = 0;
  size_t len;

  bin = fopen(path, "rb");

  if(bin == NULL) {
    printf("error: file not found!\n");
    return -1;
  }

  if((mem_size > 0) && (oset > 0)) {
    fseek(bin, oset, SEEK_CUR);
  }

  if((mem_size == 0) && (oset > 0)) {
    fseek(bin, oset, SEEK_END);
    mem_size = ftell(bin);
    rewind(bin);
    fseek(bin, oset, SEEK_CUR);
  }

  if((mem_size == 0) && (oset == 0)) {
    fseek(bin, oset, SEEK_END);
    mem_size = ftell(bin);
    rewind(bin);
  }

  bin_mem = (char*)malloc(mem_size);

  if(bin_mem == NULL) {
    printf("error: allocation too big\n");
    return -2;
  }

  fread(bin_mem, 1, mem_size, bin);

  len = mem_size;

  printf("%08lx  ", oset);

  while(hpos <= len) {
    for(cind = 0; cind < cell && hpos <= len; cind++, hpos++) {
      printf("%02x ", (unsigned char)*(bin_mem+hpos));
        if(cind == 7) {
          printf("  ");
        }
    }
    if(cind < cell) {
      if(cind <= 7) {
        for(; cind < 8; cind++) {
          printf("   ");
        }
        printf("  ");
      }
      for(; cind <= cell-1; cind++) {
        printf("   ");
      }
    }
    printf("  |");
    for(cind = 0; cind < cell && apos <= len; cind++, apos++) {
      if(isprint((int)*(bin_mem+apos))) {
        printf("%c", (unsigned char)*(bin_mem+apos));
      }
      else {
        printf(".");
      }
    }
    printf("|\n");
    printf("%08lx  ", oset+=cell);
  }

  free(bin_mem);
  fclose(bin);
  printf("\n");

  return 0;
}
